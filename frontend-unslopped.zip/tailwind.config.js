/** @type {import('tailwindcss').Config} */

// One palette for the whole app. Existing utility classes (slate-*, blue-*, etc.)
// are remapped here so every view picks up the same system:
//   slate  -> warm graphite (surfaces, borders, text)
//   blue   -> brass (the single accent: actions, focus, active state)
//   indigo / sky / cyan / violet -> brass or steel, so nothing reads as a second brand colour
const graphite = {
  50: '#f1efea',
  100: '#e6e3dc',
  200: '#cfccc4',
  300: '#b4b1a9',
  400: '#8f8d87',
  500: '#6f6e6a',
  600: '#4a4c4d',
  700: '#33373a',
  800: '#25292c',
  900: '#1b1e21',
  950: '#141618',
};

const brass = {
  50: '#faf6e8',
  100: '#f2e8c4',
  200: '#e6d391',
  300: '#d9bd62',
  400: '#cfa947',
  500: '#c0962f',
  600: '#8c6a1c',
  700: '#74571a',
  800: '#6b4d1c',
  900: '#573f1a',
  950: '#2e210c',
};

const steel = {
  50: '#f2f5f6',
  100: '#e1e8ea',
  200: '#c6d3d7',
  300: '#9fb4bb',
  400: '#7595a0',
  500: '#5a7a86',
  600: '#496370',
  700: '#3d525d',
  800: '#35444d',
  900: '#2f3c43',
  950: '#1c2529',
};

export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        // headings: kept under the old `font-space` name so existing markup keeps working
        space: ['"Barlow Semi Condensed"', '"IBM Plex Sans"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      colors: {
        slate: graphite,
        zinc: graphite,
        gray: graphite,
        blue: brass,
        indigo: brass,
        violet: brass,
        sky: steel,
        cyan: steel,
        primary: {
          DEFAULT: brass[500],
          hover: brass[400],
          foreground: '#17140b',
        },
        border: 'rgba(255, 255, 255, 0.1)',
        card: {
          DEFAULT: '#1e2226',
          foreground: '#f1efea',
        },
        muted: {
          DEFAULT: 'rgba(255, 255, 255, 0.06)',
          foreground: '#8f8d87',
        },
      },
      width: {
        '84': '21rem',
      },
    },
  },
  plugins: [],
}
