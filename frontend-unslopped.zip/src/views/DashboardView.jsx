import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { api } from '../api';
import { getStatusStyle } from '../utils/statusColors';

// DiscreteTabs, ShowQr, CommandSearch, FilterDisclosure components
import { DiscreteTabs } from '../components/DiscreteTabs';
import { ShowQr } from '../components/ShowQr';
import { CommandSearch } from '../components/CommandSearch';
import { FilterDisclosure } from '../components/FilterDisclosure';
import ProfileModal from '../components/ProfileModal';

// React-Icons requested by user
import { FaBell, FaTasks } from 'react-icons/fa';
import { FaBell as FaBell6 } from 'react-icons/fa6';
import { HiCalendarDays } from 'react-icons/hi2';
import { MdMailOutline } from 'react-icons/md';
import { IoCalendar } from 'react-icons/io5';
import { BsFillPeopleFill, BsPinFill } from 'react-icons/bs';
import { RiBubbleChartFill } from 'react-icons/ri';

// Lucide Icons
import {
  Folder,
  Calendar,
  X,
  Plus,
  Radio,
  Gauge,
  AlertCircle,
  UserCheck,
  TrendingUp,
  Workflow,
  LayoutGrid,
  Bookmark,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Wrench,
  CheckCircle2,
  AlertTriangle,
  Check,
  Copy,
  Box,
  SlidersHorizontal,
  Clock,
  Layers,
  ChevronDown,
  Link as LinkIcon,
  Search,
  MoreVertical,
  Activity,
  ShieldCheck,
  Lock,
  Printer,
  FileText
} from 'lucide-react';

const SOP_PLAYBOOKS = [
  {
    id: 'sop-1',
    title: 'ISO-9001 Calibration & Torque Tolerance Protocols',
    author: 'Alex Rivera • Plant Admin',
    role: 'Lead Metrology Specialist',
    duration: '5 min read',
    accentColor: '#a855f7',
    accentBg: 'bg-violet-500/10 text-violet-300 border-violet-500/20',
    borderHover: 'hover:border-violet-500/40',
    iso: 'ISO-9001 / ISO-6789',
    filterPreset: 'awaiting_inspection',
    overview: 'Standardized calibration workflow ensuring all digital and micrometer torque wrenches maintain strict tolerances within ±1% across line assembly cells.',
    steps: [
      'Perform zero-point calibration against laboratory master load cell standard.',
      'Record 10 sample readings at 20%, 60%, and 100% rated capacity.',
      'Verify transducer drift remains under ±0.002 N·m tolerance envelope.',
      'Affix tamper-evident holographic calibration label with 90-day expiry date.',
      'Upload calibration certificate to ToolTrack compliance register.'
    ],
    ppe: ['Safety Glasses', 'Cleanroom Nitrile Gloves', 'Static Discharge Strap']
  },
  {
    id: 'sop-2',
    title: 'Spindle Runout & High-Vibration Preventive Servicing',
    author: 'Marcus Vance • Assembly',
    role: 'Senior CNC Line Machinist',
    duration: '8 min read',
    accentColor: '#f59e0b',
    accentBg: 'bg-amber-500/10 text-amber-300 border-amber-500/20',
    borderHover: 'hover:border-amber-500/40',
    iso: 'Machinery Safety DIN-69871',
    filterPreset: 'maintenance_due',
    overview: 'Daily pre-shift thermal warmup cycle and dial test indicator runout verification for BT40/CAT50 machining spindles prior to heavy roughing operations.',
    steps: [
      'Clean spindle internal taper and toolholder shank with lint-free solvent wipe.',
      'Mount calibrated dial test indicator against spindle test arbor ground diameter.',
      'Manually rotate spindle 360° to ensure Total Indicator Reading (TIR) ≤ 0.003 mm.',
      'Execute 15-minute stepped warmup routine (3000 -> 6000 -> 12000 RPM).',
      'Verify coolant delivery pressure reaches nominal 2.2 bar with zero cavitation.'
    ],
    ppe: ['Safety Glasses with Side Shields', 'Steel-Toe Boots', 'Ear Protection']
  },
  {
    id: 'sop-3',
    title: 'First-Day Tool Crib Safety, Tagout & Clearance',
    author: 'Sarah Chen • QA Lab',
    role: 'Industrial Safety Specialist',
    duration: '4 min read',
    accentColor: '#10b981',
    accentBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20',
    borderHover: 'hover:border-emerald-500/40',
    iso: 'OSHA 1910.147 / LOTO',
    filterPreset: 'available',
    overview: 'Mandatory checkout and custody verification guidelines for line technicians operating pneumatic, hydraulic, and high-voltage shopfloor tools.',
    steps: [
      'Inspect air supply hoses and quick-disconnect fittings for micro-cracks and abrasion.',
      'Verify emergency shutoff dead-man switches trigger immediately without stickiness.',
      'Scan equipment 2D QR asset tag against the ToolTrack checkout kiosk.',
      'Confirm tool custody is formally logged under your operator profile before bay transport.',
      'Store in designated yellow staging rack when idle during shift changeovers.'
    ],
    ppe: ['Cut-Resistant Level 5 Gloves', 'Impact Goggles', 'High-Visibility Vest']
  },
  {
    id: 'sop-4',
    title: 'Automated Barcode & NFC Tag Tracking Across Factory Shifts',
    author: 'Elena Rostova • Tool Crib Lead',
    role: 'Inventory Logistics Lead',
    duration: '6 min read',
    accentColor: '#06b6d4',
    accentBg: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20',
    borderHover: 'hover:border-cyan-500/40',
    iso: 'ISO-28560 RFID Standards',
    filterPreset: 'all',
    overview: 'Shift changeover protocol for batch scanning tools returned to Cribs 1, 2, and 3 to ensure zero unaccounted equipment and automated discrepancy logging.',
    steps: [
      'Badge in at the station terminal using your employee RFID badge.',
      'Present the tool asset tag to the high-speed omni-directional 2D barcode scanner.',
      'Confirm visual on-screen status updates to "Returned" and audit timestamp is recorded.',
      'Inspect tool cutting edges and cables for mechanical damage prior to rack storage.',
      'If damaged, flag tool as "Maintenance Required" to route to quarantine bay.'
    ],
    ppe: ['Safety Glasses', 'Nitrile Gloves']
  },
  {
    id: 'sop-5',
    title: 'Defect Needs maintenance Triage: Managing Damaged Drill Bits',
    author: 'David Okafor • Reliability Maint.',
    role: 'Maintenance specialist',
    duration: '4 min read',
    accentColor: '#ef4444',
    accentBg: 'bg-rose-500/10 text-rose-300 border-rose-500/20',
    borderHover: 'hover:border-rose-500/40',
    iso: 'Metrology QC-STD-14',
    filterPreset: 'maintenance_due',
    overview: 'Immediate quarantine protocols for micro-chipped carbide cutters, dull reamers, and bent end mills to prevent work-in-progress scrapping.',
    steps: [
      'Flag tool as "Sent for Maintenance" at the ToolTrack station terminal.',
      'Affix high-visibility red quarantine tag with operator signature and timestamp.',
      'Examine cutting edge flank wear under the 50x optical microscope (>0.3mm = regrind).',
      'Place into locked red quarantine cart in Bay A awaiting CNC regrinding service.',
      'Log maintenance ticket with estimated return-to-service date.'
    ],
    ppe: ['Chemical-Resistant Gloves', 'Safety Glasses']
  },
  {
    id: 'sop-6',
    title: 'Equipment Lifecycle Cost Analysis & Spares Logistics',
    author: 'Kavita Patel • Safety Officer',
    role: 'Plant Asset Director',
    duration: '7 min read',
    accentColor: '#3b82f6',
    accentBg: 'bg-blue-500/10 text-blue-300 border-blue-500/20',
    borderHover: 'hover:border-blue-500/40',
    iso: 'Asset Mgmt ISO-55001',
    filterPreset: 'all',
    overview: 'Comprehensive economic lifecycle evaluation for determining rebuild versus replacement tipping points on high-cycle pneumatic and electric drivers.',
    steps: [
      'Calculate cumulative maintenance expenditures against initial asset acquisition cost.',
      'Review mean time between failures (MTBF) over the preceding 180 operating days.',
      'Verify OEM spare parts availability and lead time from regional distributor.',
      'If repair exceeds 50% replacement value, initiate asset retirement authorization.',
      'Archive serial number and print decommissioning audit trail documentation.'
    ],
    ppe: ['Safety Glasses']
  }
];

export default function DashboardView({ onSelectTool, onRegisterNew, onScanQR, onNavigateView, user }) {
  const [tools, setTools] = useState([]);
  const [alertsData, setAlertsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Selected tool in master-detail view
  const [selectedToolId, setSelectedToolId] = useState(null);

  // Reference 4: "Create New" Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);

  // SOP / Playbook Reader Modal State
  const [selectedSOP, setSelectedSOP] = useState(null);
  const [showSOPModal, setShowSOPModal] = useState(false);
  const [completedSteps, setCompletedSteps] = useState({});

  // Action Modals
  const [showMaintModal, setShowMaintModal] = useState(false);
  const [showCalibModal, setShowCalibModal] = useState(false);
  const [showQASignoffModal, setShowQASignoffModal] = useState(false);

  // Form states for Maintenance Modal
  const [maintToolId, setMaintToolId] = useState('');
  const [maintType, setMaintType] = useState('Routine Spindle Warmup & Recalibration');
  const [maintTechnician, setMaintTechnician] = useState(user?.full_name || 'Marcus Vance');
  const [maintNotes, setMaintNotes] = useState('');
  const [maintLoading, setMaintLoading] = useState(false);

  // Form states for Calibration Modal
  const [calibToolId, setCalibToolId] = useState('');
  const [calibCertId, setCalibCertId] = useState('CAL-2026-884');
  const [calibTolerance, setCalibTolerance] = useState('±0.001 mm TIR');
  const [calibStandard, setCalibStandard] = useState('ISO-9001 / ISO-6789 Metrology');
  const [calibLoading, setCalibLoading] = useState(false);

  // Form states for QA Signoff Modal
  const [qaToolId, setQaToolId] = useState('');
  const [qaChecks, setQaChecks] = useState({ runout: true, electrical: true, barcode: true, guard: true });
  const [qaReturnLocation, setQaReturnLocation] = useState('Bay A');
  const [qaSignoffNotes, setQaSignoffNotes] = useState('');
  const [qaSignoffLoading, setQaSignoffLoading] = useState(false);

  // Global Toast Success Banner
  const [toastMessage, setToastMessage] = useState(null);

  // Filter States
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('All');
  const [locationFilter, setLocationFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [activePreset, setActivePreset] = useState('all'); // all, overdue, awaiting_inspection, maintenance_due, available, in_use
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedDisclosureFilters, setSelectedDisclosureFilters] = useState([]);

  // View mode switcher: 'split' (Master-Detail), 'table' (Dense Ledger), 'grid' (Card Grid)
  const [viewMode, setViewMode] = useState('split');
  const [showViewMenu, setShowViewMenu] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showBatchQrModal, setShowBatchQrModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showAlertsPopover, setShowAlertsPopover] = useState(false);
  const [currentUser, setCurrentUser] = useState(user || { full_name: 'Alex Rivera', role: 'Admin', department: 'Plant Admin' });
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Selected station in Card 4 payout/triage
  const [activeStationCard, setActiveStationCard] = useState('crib');

  // Quick Action Modal State (Direct Check-out / Return from Dashboard)
  const [quickActionTool, setQuickActionTool] = useState(null);
  const [quickActionType, setQuickActionType] = useState('Issue'); // 'Issue', 'Return', 'Inspect'
  const [qaLocation, setQaLocation] = useState('');
  const [qaExpectedReturn, setQaExpectedReturn] = useState('');
  const [qaNotes, setQaNotes] = useState('');
  const [qaMaintenanceFlag, setQaMaintenanceFlag] = useState(false);
  const [qaSubmitting, setQaSubmitting] = useState(false);
  const [qaError, setQaError] = useState(null);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (department !== 'All') params.department = department;
      if (locationFilter !== 'All') params.location = locationFilter;
      if (statusFilter !== 'All') params.status = statusFilter;
      if (activePreset !== 'all') params.filter = activePreset;
      if (startDate) params.start_date = startDate;
      if (endDate) params.end_date = endDate;

      const [toolsRes, alertsRes] = await Promise.all([
        api.getTools(params),
        api.getAlerts()
      ]);

      const fetchedTools = toolsRes.tools || [];
      setTools(fetchedTools);
      setAlertsData(alertsRes);

      if (fetchedTools.length > 0 && !selectedToolId) {
        setSelectedToolId(fetchedTools[0].id);
      }
    } catch (err) {
      setError(err.message || 'Failed to retrieve dashboard records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [search, department, locationFilter, statusFilter, activePreset, startDate, endDate]);

  const handleResetFilters = () => {
    setSearch('');
    setDepartment('All');
    setLocationFilter('All');
    setStatusFilter('All');
    setActivePreset('all');
    setStartDate('');
    setEndDate('');
    setSelectedDisclosureFilters([]);
    setToastMessage('All fleet filters have been reset to default.');
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleExportFleetCsv = () => {
    try {
      const headers = ['Tool ID', 'Equipment Name', 'Type', 'Status', 'Department', 'Current Location', 'Home Location', 'Serial Number', 'Current Custodian'];
      const rows = tools.map(t => [
        t.id,
        `"${(t.name || '').replace(/"/g, '""')}"`,
        `"${(t.type || '').replace(/"/g, '""')}"`,
        t.current_status,
        `"${(t.department || '').replace(/"/g, '""')}"`,
        `"${(t.current_location || '').replace(/"/g, '""')}"`,
        `"${(t.home_location || '').replace(/"/g, '""')}"`,
        `"${(t.serial_number || '').replace(/"/g, '""')}"`,
        `"${(t.owner || '').replace(/"/g, '""')}"`
      ]);
      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `tooltrack_active_fleet_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setToastMessage(`Exported ${tools.length} equipment records to CSV successfully.`);
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err) {
      console.error('Export error:', err);
    }
  };

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await fetchDashboardData();
      setToastMessage('Equipment fleet telemetry and status refreshed.');
    } catch (e) {
      setToastMessage('Telemetry refresh completed.');
    } finally {
      setIsRefreshing(false);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleOpenQuickAction = (tool, type) => {
    setQuickActionTool(tool);
    setQuickActionType(type);
    setQaLocation(tool.current_location || tool.home_location);
    setQaExpectedReturn('');
    setQaNotes('');
    setQaMaintenanceFlag(false);
    setQaError(null);
  };

  const handleQuickActionSubmit = async (e) => {
    e.preventDefault();
    if (!quickActionTool) return;

    setQaSubmitting(true);
    setQaError(null);

    try {
      let targetStatus = 'In Use';
      if (quickActionType === 'Issue') targetStatus = 'Issued';
      if (quickActionType === 'Return') targetStatus = 'Returned';
      if (quickActionType === 'Inspect') targetStatus = 'Inspected';

      const payload = {
        status: targetStatus,
        location: qaLocation,
        notes: qaNotes || `Quick transition to ${targetStatus} from dashboard terminal.`,
        maintenance_flag: qaMaintenanceFlag ? 1 : 0
      };

      if (targetStatus === 'Issued' && qaExpectedReturn) {
        payload.expected_return_date = qaExpectedReturn;
      }

      await api.addEvent(quickActionTool.id, payload);
      setQuickActionTool(null);
      setToastMessage(`Tool ${quickActionTool.id} transitioned to ${targetStatus}`);
      setTimeout(() => setToastMessage(null), 3000);
      await fetchDashboardData();
    } catch (err) {
      setQaError(err.message || 'Failed to commit status change.');
    } finally {
      setQaSubmitting(false);
    }
  };

  const departments = [
    'All',
    'Assembly',
    'Quality Assurance',
    'Maintenance',
    'Fabrication',
    'Machining',
    'Carpentry & Crating',
    'Shop Management'
  ];

  const statuses = [
    'All',
    'Registered',
    'Received',
    'Inspected',
    'Issued',
    'In Use',
    'Returned',
    'Sent for Maintenance',
    'Repaired',
    'Retired'
  ];

  const today = new Date().toISOString().split('T')[0];

  // Calculate fleet metrics
  const totalFleet = tools.length;
  const availableFleet = tools.filter(t => ['Inspected', 'Repaired', 'Returned'].includes(t.current_status) && t.maintenance_flag === 0).length;
  const inUseFleet = tools.filter(t => ['Issued', 'In Use'].includes(t.current_status)).length;
  const maintenanceFleet = tools.filter(t => t.maintenance_flag === 1 || t.current_status === 'Sent for Maintenance').length;
  const awaitingInspectionFleet = tools.filter(t => ['Registered', 'Received'].includes(t.current_status)).length;
  const overdueCount = alertsData?.summary?.overdue_count || 0;

  const availabilityPct = totalFleet > 0 ? Math.round((availableFleet / totalFleet) * 100) : 0;
  const inUsePct = totalFleet > 0 ? Math.round((inUseFleet / totalFleet) * 100) : 0;

  // Selected tool object for detail showcase
  const selectedTool = tools.find(t => t.id === selectedToolId) || tools[0] || null;

  const handleOpenSOP = (sop) => {
    setSelectedSOP(sop);
    setShowSOPModal(true);
  };

  const toggleStep = (index) => {
    setCompletedSteps(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  // Commands for the CommandSearch component
  const commandItems = useMemo(() => {
    const list = [
      {
        id: 'cmd-register',
        title: 'Register tool Asset',
        section: 'Actions',
        icon: <Plus size={16} />,
        shortcut: '⌘ R',
        action: () => onRegisterNew && onRegisterNew()
      },
      {
        id: 'cmd-scan',
        title: 'Scan Tool QR Barcode',
        section: 'Actions',
        icon: <Radio size={16} />,
        shortcut: '⌘ S',
        action: () => onScanQR && onScanQR()
      },
      {
        id: 'cmd-maint',
        title: 'Log Equipment Maintenance',
        section: 'Actions',
        icon: <Wrench size={16} />,
        shortcut: '⌘ M',
        action: () => setShowMaintModal(true)
      },
      {
        id: 'cmd-calib',
        title: 'Schedule Spindle Calibration',
        section: 'Actions',
        icon: <Calendar size={16} />,
        shortcut: '⌘ C',
        action: () => setShowCalibModal(true)
      },
      {
        id: 'cmd-qa',
        title: 'QA Inspection & Signoff',
        section: 'Actions',
        icon: <CheckCircle2 size={16} />,
        shortcut: '⌘ Q',
        action: () => setShowQASignoffModal(true)
      },
      {
        id: 'cmd-reports',
        title: 'Audit reports',
        section: 'Navigation',
        icon: <FileText size={16} />,
        shortcut: '⌘ A',
        action: () => onNavigateView && onNavigateView('reports')
      }
    ];

    tools.slice(0, 10).forEach(tool => {
      list.push({
        id: `tool-${tool.id}`,
        title: `${tool.id} - ${tool.name} (${tool.current_status})`,
        section: 'Equipment',
        icon: <Box size={16} />,
        action: () => {
          setSelectedToolId(tool.id);
          onSelectTool(tool.id);
        }
      });
    });

    return list;
  }, [tools, onRegisterNew, onScanQR, onNavigateView, onSelectTool]);

  // FilterDisclosure Items (requested by user)
  const disclosureFilterItems = [
    { id: 'tasks', label: 'Tasks', icon: FaTasks },
    { id: 'events', label: 'Events', icon: IoCalendar },
    { id: 'reminders', label: 'Reminders', icon: FaBell },
    { id: 'appointments', label: 'Appointment', icon: BsPinFill },
    { id: 'meetings', label: 'Meetings', icon: BsFillPeopleFill },
    { id: 'celebrations', label: 'Certifications', icon: RiBubbleChartFill },
  ];

  // DiscreteTabs Navigation Items (requested by user)
  const topNavTabs = [
    {
      id: 'overview',
      icon: <MdMailOutline size={18} />,
      label: 'Overview',
      activeColor: 'text-indigo-400'
    },
    {
      id: 'fleet',
      icon: <HiCalendarDays size={18} />,
      label: 'Equipment',
      activeColor: 'text-yellow-400',
      badge: totalFleet
    },
    {
      id: 'alerts',
      icon: <FaBell6 size={18} />,
      label: 'Alerts',
      activeColor: 'text-red-400',
      badge: overdueCount > 0 ? overdueCount : undefined
    }
  ];

  // Lower container status filter tabs
  const lowerFilterTabs = [
    { id: 'all', icon: <Layers size={14} />, label: 'All Equipment', badge: totalFleet },
    { id: 'available', icon: <CheckCircle2 size={14} />, label: 'Available', badge: availableFleet },
    { id: 'in_use', icon: <Radio size={14} />, label: 'In use', badge: inUseFleet },
    { id: 'maintenance_due', icon: <Wrench size={14} />, label: 'Needs maintenance', badge: maintenanceFleet },
    { id: 'awaiting_inspection', icon: <Clock size={14} />, label: 'Awaiting QA', badge: awaitingInspectionFleet },
    { id: 'overdue', icon: <AlertTriangle size={14} />, label: 'Overdue', badge: overdueCount > 0 ? overdueCount : undefined }
  ];

  return (
    <div className="w-full min-h-screen bg-[#121416] p-3 sm:p-6 lg:p-8 font-sans transition-colors duration-300">
      {/* Outer Shell Window (Matches Precision Sapphire & Obsidian Frame) */}
      <div className="max-w-[1440px] mx-auto space-y-8">
        
        {/* ========================================================================= */}
        {/* 1. TOP NAVBAR: Brand + DiscreteTabs Navigation Capsule + Utility Circles  */}
        {/* ========================================================================= */}
        <div className="flex items-center justify-end gap-4 pb-4 border-b border-[#31363a]">
          {/* Right Utility Circles & Profile (All 4 Fully Interactive) */}
          <div className="flex items-center space-x-2">
            {/* Button 1: Reports & Analytics */}
            <button
              type="button"
              onClick={() => {
                if (onNavigateView) onNavigateView('reports');
                setToastMessage('Switching to Reports');
                setTimeout(() => setToastMessage(null), 2500);
              }}
              className="w-9 h-9 rounded-full bg-[#1e2226] hover:bg-[#272c30] text-slate-300 hover:text-white border border-[#31363a] hover:border-blue-500 flex items-center justify-center transition hover:scale-105 active:scale-95"
              title="Reports & Analytics"
            >
              <FileText className="w-4 h-4 text-slate-300" />
            </button>

            {/* Button 2: Calibration & Metrology Calendar Modal */}
            <button
              type="button"
              onClick={() => setShowCalibModal(true)}
              className="w-9 h-9 rounded-full bg-[#1e2226] hover:bg-[#272c30] text-slate-300 hover:text-white border border-[#31363a] hover:border-blue-500 flex items-center justify-center transition hover:scale-105 active:scale-95"
              title="Calibration & Maintenance Calendar"
            >
              <Calendar className="w-4 h-4 text-slate-300" />
            </button>

            {/* Button 3: Alerts Popover */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowAlertsPopover(!showAlertsPopover)}
                className={`relative w-9 h-9 rounded-full bg-[#1e2226] hover:bg-[#272c30] text-slate-300 hover:text-white border border-[#31363a] hover:border-blue-500 flex items-center justify-center transition hover:scale-105 active:scale-95 ${
                  showAlertsPopover ? 'border-blue-500' : ''
                }`}
                title="Operational Alerts Center"
              >
                <FaBell className="w-3.5 h-3.5 text-slate-300" />
                {overdueCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-rose-500 border-2 border-[#181b1e] animate-pulse" />
                )}
              </button>

              <AnimatePresence>
                {showAlertsPopover && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-80 rounded-lg bg-[#181b1e] border border-[#31363a] shadow-2xl p-4 z-50 text-white"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-[#31363a] mb-3">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                        <h4 className="font-space font-bold text-xs text-white">Alerts</h4>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                        {overdueCount} Overdue
                      </span>
                    </div>

                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1 text-xs">
                      {tools.filter(t => t.current_status === 'overdue' || t.current_status === 'maintenance_due').length === 0 ? (
                        <div className="p-4 text-center text-slate-400 font-mono text-[11px]">
                          Zero critical equipment alerts.
                        </div>
                      ) : (
                        tools
                          .filter(t => t.current_status === 'overdue' || t.current_status === 'maintenance_due')
                          .slice(0, 5)
                          .map(t => (
                            <div
                              key={t.id}
                              onClick={() => {
                                setSelectedToolId(t.id);
                                setShowAlertsPopover(false);
                              }}
                              className="p-2.5 rounded-md bg-[#1e2226] border border-[#31363a] hover:border-blue-500 cursor-pointer transition flex items-center justify-between"
                            >
                              <div>
                                <div className="font-bold text-white text-[11px]">{t.id} • {t.name}</div>
                                <div className="text-[10px] text-slate-400 font-mono">{t.department} • {t.current_location}</div>
                              </div>
                              <span className="text-[10px] font-bold text-rose-400 font-mono">
                                {t.current_status === 'overdue' ? 'Overdue' : 'Defect'}
                              </span>
                            </div>
                          ))
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setActivePreset('overdue');
                        setShowAlertsPopover(false);
                      }}
                      className="w-full mt-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition text-center"
                    >
                      Show overdue
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Button 4: User Profile Avatar with Click to Edit */}
            <div
              onClick={() => setShowProfileModal(true)}
              className="relative cursor-pointer pl-1 group"
              title="Click to view & edit your personnel profile"
            >
              <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs border-2 border-[#31363a] group-hover:scale-105 transition-transform">
                {currentUser?.full_name ? currentUser.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'AR'}
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#181b1e]" />
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. TITLE BAR: Back Arrow + Page Header + Filter Icon + "+ Register Tool"  */}
        {/* ========================================================================= */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <button
              type="button"
              onClick={handleResetFilters}
              className="w-10 h-10 rounded-full bg-[#1e2226] hover:bg-[#272c30] text-slate-300 hover:text-white border border-[#31363a] hover:border-blue-500 flex items-center justify-center transition hover:scale-105"
            >
              <ArrowLeft className="w-4 h-4 text-slate-300" />
            </button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold font-space text-white tracking-tight">
                Equipment
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Every tool in the workshop, with its status, owner and calibration.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setActivePreset(activePreset === 'in_use' ? 'all' : 'in_use')}
              className="w-10 h-10 rounded-lg bg-[#1e2226] hover:bg-[#272c30] text-slate-300 border border-[#31363a] flex items-center justify-center hover:border-blue-500 transition"
              title="Toggle In-Use Filter"
            >
              <SlidersHorizontal className="w-4 h-4 text-slate-300" />
            </button>

            <button
              type="button"
              onClick={() => onRegisterNew && onRegisterNew()}
              className="px-5 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>Register tool</span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 4. ACTIVE FILTERS RIBBON (FilterDisclosure + Date Pickers + CommandSearch)*/}
        {/* ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2.5 flex-wrap">
            {/* Active Filters Counter Pill */}
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-[#1e2226] text-slate-200 border border-[#31363a] text-xs font-semibold">
              <span>Active filters</span>
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-mono">
                {selectedDisclosureFilters.length}
              </span>
            </div>

            {/* FilterDisclosure Button (User's Exact Component) */}
            <FilterDisclosure
              items={disclosureFilterItems}
              selectedIds={selectedDisclosureFilters}
              buttonLabel="Filter & Sort"
              onConfirm={(ids) => {
                setSelectedDisclosureFilters(ids);
                if (ids.includes('reminders')) setActivePreset('overdue');
                else if (ids.includes('tasks')) setActivePreset('maintenance_due');
                else if (ids.includes('events')) setActivePreset('in_use');
              }}
              onReset={() => handleResetFilters()}
            />

            {/* Date Pickers */}
            <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#1e2226] border border-[#31363a] text-xs text-slate-300">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>November 2026</span>
            </div>
            <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#1e2226] border border-[#31363a] text-xs text-slate-300">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>December 2026</span>
            </div>
          </div>

          {/* CommandSearch Component (User's Exact Component) */}
          <div className="w-full md:w-auto">
            <CommandSearch
              items={commandItems}
              placeholder="Search by tool ID or name"
              onQueryChange={(q) => setSearch(q)}
            />
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 5. LOWER MASTER-DETAIL DARK CONTAINER: Left List + Right Detail Showcase  */}
        {/* ========================================================================= */}
        <div className="bg-[#101214] rounded-lg  p-6 sm:p-8 text-white shadow-2xl border border-[#31363a] space-y-6">
          
          {/* Top Header Row of Lower Section */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#31363a]">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold font-space text-white">Equipment</h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30">
                  {tools.length} Registered
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">Status, custody and calibration for each tool</p>
            </div>

            {/* DiscreteTabs Filter Capsule + View Switcher + Actions */}
            <div className="flex items-center gap-3">
              <DiscreteTabs
                tabs={lowerFilterTabs}
                value={activePreset}
                onChange={(id) => setActivePreset(id)}
                className="bg-[#1e2226] border-[#31363a]"
              />

              <div className="flex items-center gap-1.5 text-slate-400">
                {/* 1. Layers View Mode Selector */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setShowViewMenu(!showViewMenu);
                      setShowMoreMenu(false);
                    }}
                    className={`p-2 rounded-md text-white transition flex items-center gap-1.5 ${
                      showViewMenu || viewMode !== 'split' ? 'bg-blue-600 text-white' : 'bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-slate-300'
                    }`}
                    title="Switch View Mode (Split, Table, Grid)"
                  >
                    <Layers className="w-4 h-4" />
                    <span className="text-[11px] font-semibold hidden xl:inline capitalize">
                      {viewMode === 'split' ? 'Split View' : viewMode === 'table' ? 'Table View' : 'Grid View'}
                    </span>
                  </button>

                  <AnimatePresence>
                    {showViewMenu && (
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-2 w-52 rounded-lg bg-[#181b1e] border border-[#31363a] shadow-2xl p-1.5 z-40 text-xs text-white"
                      >
                        <div className="px-3 py-1.5 text-[10px] font-mono text-blue-400 border-b border-[#31363a]">
                          Layout
                        </div>
                        {[
                          { id: 'split', label: 'Master-Detail Split', desc: 'Side-by-side inspection', icon: Box },
                          { id: 'table', label: 'Dense Table Ledger', desc: 'Fast row audit & scan', icon: Layers },
                          { id: 'grid', label: 'Card grid', desc: 'Cards', icon: LayoutGrid },
                        ].map((item) => {
                          const Icon = item.icon;
                          return (
                            <button
                              key={item.id}
                              type="button"
                              onClick={() => {
                                setViewMode(item.id);
                                setShowViewMenu(false);
                                setToastMessage(`Switched to ${item.label}`);
                                setTimeout(() => setToastMessage(null), 2000);
                              }}
                              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left transition ${
                                viewMode === item.id ? 'bg-blue-600 text-white font-bold' : 'hover:bg-[#1e2226] text-slate-300 hover:text-white'
                              }`}
                            >
                              <Icon className="w-3.5 h-3.5 text-blue-400" />
                              <div>
                                <div className="font-semibold text-xs leading-none">{item.label}</div>
                                <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                              </div>
                            </button>
                          );
                        })}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* 2. More Fleet Actions Dropdown */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreMenu(!showMoreMenu);
                      setShowViewMenu(false);
                    }}
                    className={`p-2 rounded-md text-white transition ${
                      showMoreMenu ? 'bg-blue-600' : 'bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-slate-300'
                    }`}
                    title="More actions"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>

                  <AnimatePresence>
                    {showMoreMenu && (
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-2 w-56 rounded-lg bg-[#181b1e] border border-[#31363a] shadow-2xl p-1.5 z-40 text-xs text-white"
                      >
                        <div className="px-3 py-1.5 text-[10px] font-mono text-blue-400 border-b border-[#31363a]">
                          Actions
                        </div>

                        {/* Action 1: Refresh Telemetry */}
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            handleManualRefresh();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left hover:bg-[#1e2226] text-slate-200 hover:text-white transition"
                        >
                          <Activity className={`w-3.5 h-3.5 text-blue-400 ${isRefreshing ? 'animate-spin' : ''}`} />
                          <span>Refresh Telemetry</span>
                        </button>

                        {/* Action 2: Export CSV */}
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            handleExportFleetCsv();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left hover:bg-[#1e2226] text-slate-200 hover:text-white transition"
                        >
                          <FileText className="w-3.5 h-3.5 text-slate-300" />
                          <span>Export to CSV</span>
                        </button>

                        {/* Action 3: Batch QR Codes Print Sheet */}
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            setShowBatchQrModal(true);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left hover:bg-[#1e2226] text-slate-200 hover:text-white transition"
                        >
                          <Copy className="w-3.5 h-3.5 text-blue-400" />
                          <span>Batch QR Asset Tags</span>
                        </button>

                        {/* Action 4: Print Registry */}
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            window.print();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left hover:bg-[#1e2226] text-slate-200 hover:text-white transition"
                        >
                          <Printer className="w-3.5 h-3.5 text-slate-300" />
                          <span>Print register</span>
                        </button>

                        <div className="my-1 border-t border-[#31363a]" />

                        {/* Action 5: Reset Filters */}
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            handleResetFilters();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left hover:bg-rose-500/15 text-rose-400 transition"
                        >
                          <X className="w-3.5 h-3.5 text-rose-400" />
                          <span>Reset All Filters</span>
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>

          {/* VIEW MODE 1: MASTER-DETAIL SPLIT GRID */}
          {viewMode === 'split' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* LEFT COLUMN: Tool Item List */}
              <div className="lg:col-span-5 space-y-2.5 max-h-[560px] overflow-y-auto pr-1">
                {loading ? (
                  <div className="p-12 text-center text-xs text-slate-400 font-mono">
                    Loading equipment assets...
                  </div>
                ) : tools.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400">
                    No equipment matches the active filters.
                  </div>
                ) : (
                  tools.map((tool) => {
                    const isSelected = selectedTool && selectedTool.id === tool.id;
                    const style = getStatusStyle(tool.current_status);

                    return (
                      <motion.div
                        key={tool.id}
                        onClick={() => setSelectedToolId(tool.id)}
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        className={`p-3.5 rounded-lg cursor-pointer transition-all duration-200 flex items-center justify-between gap-3 border select-none ${
                          isSelected
                            ? 'bg-blue-600/15 border-blue-500'
                            : 'bg-[#1e2226] hover:bg-[#272c30] border-[#31363a] hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-3 truncate">
                          {/* Avatar */}
                          <div className="w-10 h-10 rounded-full bg-[#181b1e] border border-[#31363a] flex items-center justify-center font-bold text-xs text-white shrink-0 overflow-hidden">
                            {tool.owner ? tool.owner.split(' ').map(n => n[0]).join('').slice(0, 2) : 'TL'}
                          </div>

                          <div className="truncate">
                            <div className="flex items-center gap-2">
                              <span className="font-space font-bold text-xs text-blue-400"># {tool.id}</span>
                              <span className="text-[10px] text-slate-400 font-mono">{tool.type || 'Tool'}</span>
                            </div>
                            <div className="text-xs text-white truncate mt-0.5">{tool.name}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2.5 shrink-0">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${style.bg} ${style.text} ${style.border}`}>
                            {tool.current_status}
                          </span>
                          <div className="text-right">
                            <div className="font-space font-bold text-xs text-white">
                              {tool.department || 'Assembly'}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono flex items-center justify-end gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400/80" />
                              <span>{tool.current_location || 'Bay A'}</span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })
                )}
              </div>

              {/* RIGHT COLUMN: Selected Equipment Showcase Detail Card */}
              <div className="lg:col-span-7">
                {selectedTool ? (
                  <motion.div
                    key={selectedTool.id}
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                    className="rounded-lg p-6 sm:p-7 text-white shadow-2xl border border-[#31363a] relative overflow-hidden bg-[#181b1e]"
                  >
                    {/* Card Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#31363a]">
                      <div>
                        <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                          <span>Tool record</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <h3 className="font-space font-bold text-2xl text-white">
                            # {selectedTool.id}
                          </h3>
                          <span className="px-3 py-0.5 rounded-full text-xs font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
                            {selectedTool.current_status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-200 mt-1 font-medium">
                          {selectedTool.name} • {selectedTool.type}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-full bg-[#1e2226] border border-[#31363a] flex items-center justify-center font-bold text-sm text-blue-400 shrink-0">
                          {selectedTool.owner ? selectedTool.owner.split(' ').map(n => n[0]).join('').slice(0, 2) : 'JC'}
                        </div>
                        <div>
                          <div className="font-bold text-sm text-white">{selectedTool.owner || 'James Carter'}</div>
                          <div className="text-[11px] text-slate-400">{selectedTool.department || 'Lead CNC Operations'}</div>
                        </div>
                      </div>
                    </div>

                    <div className="my-6" />

                    {/* Card Bottom: Subtotals & Actions */}
                    <div className="pt-4 border-t border-[#31363a] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-6 text-xs text-slate-300">
                        <div>
                          <div className="text-[10px] font-mono text-slate-400">Home Location</div>
                          <div className="font-bold text-white font-space mt-0.5">{selectedTool.home_location}</div>
                        </div>
                        <div>
                          <div className="text-[10px] font-mono text-slate-400">Current Bay</div>
                          <div className="font-bold text-white font-space mt-0.5">{selectedTool.current_location}</div>
                        </div>
                        <div>
                          <div className="text-[10px] font-mono text-slate-400">Serial Number</div>
                          <div className="font-mono text-white mt-0.5">{selectedTool.serial_number}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* ShowQr Component (User's Exact Component) */}
                        <ShowQr
                          value={`TOOLTRACK-${selectedTool.id}`}
                          buttonLabel="Show QR Code"
                          onCopy={() => {
                            setToastMessage(`QR Code for ${selectedTool.id} copied!`);
                            setTimeout(() => setToastMessage(null), 2500);
                          }}
                        />

                        <button
                          type="button"
                          onClick={() => handleOpenQuickAction(selectedTool, 'Issue')}
                          className="py-2.5 px-6 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-extrabold transition flex items-center gap-2 hover:scale-105 active:scale-95"
                        >
                          <span>Check out</span>
                          <ArrowRight className="w-3.5 h-3.5 text-white" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ) : null}
              </div>
            </div>
          )}

          {/* VIEW MODE 2: DENSE TABLE LEDGER */}
          {viewMode === 'table' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="overflow-x-auto rounded-lg border border-[#31363a] bg-[#181b1e]"
            >
              <table className="min-w-full divide-y divide-[#31363a] text-left text-xs">
                <thead className="bg-[#1e2226] text-slate-300 font-semibold text-[11px] border-b border-[#31363a]">
                  <tr>
                    <th className="py-3 px-4">Asset ID</th>
                    <th className="py-3 px-4">Equipment Name</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Department</th>
                    <th className="py-3 px-4">Current Bay</th>
                    <th className="py-3 px-4">Custodian</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#31363a] text-slate-200">
                  {tools.map((tool) => {
                    const style = getStatusStyle(tool.current_status);
                    return (
                      <tr key={tool.id} className="hover:bg-[#1e2226]/60 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-blue-400"># {tool.id}</td>
                        <td className="py-3 px-4 font-semibold text-white">{tool.name}</td>
                        <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">{tool.type}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${style.bg} ${style.text} ${style.border}`}>
                            {tool.current_status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-white">{tool.department}</td>
                        <td className="py-3 px-4 font-mono text-slate-300">{tool.current_location}</td>
                        <td className="py-3 px-4 text-slate-300">{tool.owner || '—'}</td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedToolId(tool.id);
                                setViewMode('split');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-white text-[11px] font-semibold transition"
                            >
                              Inspect
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOpenQuickAction(tool, 'Issue')}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold transition"
                            >
                              Action
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </motion.div>
          )}

          {/* VIEW MODE 3: EQUIPMENT CARD GRID */}
          {viewMode === 'grid' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4"
            >
              {tools.map((tool) => {
                const style = getStatusStyle(tool.current_status);
                return (
                  <motion.div
                    key={tool.id}
                    whileHover={{ y: -3 }}
                    className="p-5 rounded-lg bg-[#181b1e] border border-[#31363a] hover:border-blue-500/50 transition-all flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-space font-bold text-sm text-blue-400"># {tool.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${style.bg} ${style.text} ${style.border}`}>
                          {tool.current_status}
                        </span>
                      </div>
                      <h4 className="font-bold text-white text-sm leading-snug">{tool.name}</h4>
                      <p className="text-[11px] text-slate-400 mt-1">{tool.type} • {tool.department}</p>
                    </div>

                    <div className="pt-3 border-t border-[#31363a] flex items-center justify-between text-xs">
                      <div>
                        <div className="text-[10px] text-slate-400 font-mono">Location</div>
                        <div className="font-semibold text-white">{tool.current_location}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <ShowQr
                          value={`TOOLTRACK-${tool.id}`}
                          buttonLabel="QR"
                          onCopy={() => setToastMessage(`QR for ${tool.id} copied!`)}
                        />
                        <button
                          type="button"
                          onClick={() => handleOpenQuickAction(tool, 'Issue')}
                          className="px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition"
                        >
                          Action
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* 6. VERIFIED SOP PLAYBOOKS (Collapsible Knowledge Base)                    */}
        {/* ========================================================================= */}
        <div className="pt-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-space font-bold text-lg text-white">
                Field Engineer Knowledge Base & SOP Playbooks
              </h3>
              <p className="text-xs text-slate-400">
                Standard operating procedures for torque tolerance, calibration, and safety
              </p>
            </div>
            <span className="text-xs font-mono text-slate-300 bg-[#1e2226] px-3 py-1 rounded-full border border-[#31363a]">
              6 Verified Protocols
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {SOP_PLAYBOOKS.map((sop) => (
              <motion.div
                key={sop.id}
                whileHover={{ y: -3, transition: { duration: 0.2 } }}
                onClick={() => handleOpenSOP(sop)}
                className="bg-[#181b1e] rounded-lg p-5 border border-[#31363a] hover: hover:border-blue-500/50 cursor-pointer transition-all flex flex-col justify-between min-h-[200px]"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="flex items-center gap-1.5 font-medium">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: sop.accentColor }} />
                      <span>{sop.duration}</span>
                    </span>
                    <Bookmark className="w-3.5 h-3.5 text-slate-500" />
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${sop.accentBg}`}>
                    {sop.iso}
                  </span>
                  <h4 className="font-space font-bold text-sm text-white mt-2 leading-snug">
                    {sop.title}
                  </h4>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#31363a] mt-4">
                  <span className="text-[11px] text-slate-400">{sop.author.split('•')[0]}</span>
                  <span className="text-xs font-bold text-blue-400 flex items-center gap-1 hover:text-blue-300">
                    Read SOP <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODALS: Quick Action, SOP Reader, Register, Maintenance, QA Signoff       */}
      {/* ========================================================================= */}

      {/* Quick Action Modal */}
      {quickActionTool && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#181b1e] rounded-lg shadow-2xl max-w-md w-full border border-[#31363a] overflow-hidden text-white"
          >
            <div className="bg-[#1e2226] px-6 py-4 flex items-center justify-between border-b border-[#31363a]">
              <div>
                <h3 className="text-sm font-bold font-space text-white">
                  Quick Action: {quickActionType === 'Issue' ? 'Check out' : quickActionType === 'Return' ? 'Return Equipment' : 'QA Signoff'}
                </h3>
                <p className="text-[11px] text-blue-400 font-mono mt-0.5">{quickActionTool.id} - {quickActionTool.name}</p>
              </div>
              <button onClick={() => setQuickActionTool(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleQuickActionSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Target Location</label>
                <input
                  type="text"
                  required
                  value={qaLocation}
                  onChange={(e) => setQaLocation(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-md bg-[#121416] border border-[#31363a] text-white focus:border-blue-500 focus:outline-none"
                />
              </div>

              {quickActionType === 'Issue' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">Expected Return Date</label>
                  <input
                    type="date"
                    value={qaExpectedReturn}
                    onChange={(e) => setQaExpectedReturn(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-md bg-[#121416] border border-[#31363a] text-white focus:border-blue-500 focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Transaction Notes</label>
                <textarea
                  rows="2"
                  value={qaNotes}
                  onChange={(e) => setQaNotes(e.target.value)}
                  placeholder="Operational notes or custody handover..."
                  className="w-full px-3.5 py-2 rounded-md bg-[#121416] border border-[#31363a] text-white focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#31363a]">
                <button
                  type="button"
                  onClick={() => setQuickActionTool(null)}
                  className="px-4 py-2 rounded-full border border-[#31363a] bg-[#1e2226] text-slate-300 hover:text-white hover:bg-[#272c30]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={qaSubmitting}
                  className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold transition"
                >
                  {qaSubmitting ? 'Committing...' : 'Commit Transaction'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* SOP Modal */}
      {showSOPModal && selectedSOP && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full max-w-xl rounded-lg bg-[#181b1e] border border-[#31363a] p-6 shadow-2xl text-white max-h-[85vh] overflow-y-auto"
          >
            <div className="flex items-start justify-between pb-4 border-b border-[#31363a]">
              <div>
                <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${selectedSOP.accentBg}`}>
                  {selectedSOP.iso}
                </span>
                <h3 className="font-space font-bold text-lg text-white mt-1.5">{selectedSOP.title}</h3>
                <p className="text-xs text-slate-400">{selectedSOP.author}</p>
              </div>
              <button onClick={() => setShowSOPModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="my-4 text-xs text-slate-300 leading-relaxed bg-[#1e2226] p-3 rounded-md border border-[#31363a]">
              {selectedSOP.overview}
            </div>

            <div className="space-y-2 mb-6">
              <h4 className="text-xs font-bold text-blue-400 font-mono">Procedure Steps:</h4>
              {selectedSOP.steps.map((step, idx) => (
                <div
                  key={idx}
                  onClick={() => toggleStep(idx)}
                  className={`flex items-start gap-3 p-3 rounded-md cursor-pointer border transition ${
                    completedSteps[idx] ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-[#1e2226]/60 border-[#31363a] text-slate-200'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 text-xs ${
                    completedSteps[idx] ? 'bg-emerald-500 text-black font-bold' : 'bg-white/10 text-slate-400'
                  }`}>
                    {completedSteps[idx] ? '✓' : idx + 1}
                  </span>
                  <span className="text-xs leading-snug">{step}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowSOPModal(false)}
              className="w-full py-2.5 rounded-full bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-white text-xs font-bold transition"
            >
              Close Protocol
            </button>
          </motion.div>
        </div>
      )}

      {/* Batch QR Tags Print Sheet Modal */}
      {showBatchQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full max-w-3xl rounded-lg bg-[#181b1e] border border-[#31363a] p-6 shadow-2xl text-white max-h-[85vh] flex flex-col justify-between"
          >
            <div className="flex items-center justify-between pb-4 border-b border-[#31363a]">
              <div>
                <h3 className="font-space font-bold text-lg text-white">Batch Equipment QR Tags</h3>
                <p className="text-xs text-slate-400">Generate and print 2D barcodes for active fleet equipment</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-1.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Sheet</span>
                </button>
                <button onClick={() => setShowBatchQrModal(false)} className="text-slate-400 hover:text-white p-1">✕</button>
              </div>
            </div>

            <div className="my-4 overflow-y-auto max-h-[55vh] pr-1 grid grid-cols-2 sm:grid-cols-3 gap-3">
              {tools.map((t) => (
                <div key={t.id} className="p-3 rounded-lg bg-[#1e2226] border border-[#31363a] flex flex-col items-center text-center space-y-2">
                  <span className="font-space font-bold text-xs text-blue-400"># {t.id}</span>
                  <div className="text-[11px] text-white font-medium line-clamp-1">{t.name}</div>
                  <ShowQr
                    value={`TOOLTRACK-${t.id}`}
                    buttonLabel="View QR"
                    onCopy={() => setToastMessage(`QR copied for ${t.id}`)}
                  />
                  <span className="text-[9px] font-mono text-slate-400">{t.current_location}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowBatchQrModal(false)}
              className="w-full py-2.5 rounded-full bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-white text-xs font-bold transition mt-2"
            >
              Close Print Sheet
            </button>
          </motion.div>
        </div>
      )}

      {/* Calibration Schedule & Metrology Calendar Modal */}
      {showCalibModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full max-w-2xl rounded-lg bg-[#181b1e] border border-[#31363a] p-6 shadow-2xl text-white max-h-[85vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-4 border-b border-[#31363a]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-space font-bold text-lg text-white">Calibration calendar</h3>
                  <p className="text-xs text-slate-400">Scheduled recalibration cycles and equipment tolerance verify dates</p>
                </div>
              </div>
              <button onClick={() => setShowCalibModal(false)} className="text-slate-400 hover:text-white p-1">✕</button>
            </div>

            <div className="my-5 space-y-3">
              {tools.slice(0, 6).map((t, idx) => (
                <div key={t.id} className="p-3.5 rounded-lg bg-[#1e2226] border border-[#31363a] flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-blue-400"># {t.id}</span>
                    <div>
                      <div className="font-bold text-sm text-white">{t.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">{t.department} • Standard: ISO-6789 / DIN-69871</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-mono bg-[#181b1e] text-slate-300 border border-[#31363a]">
                      Due: Nov {18 + (idx * 2)}, 2026
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setToastMessage(`Calibration verified and registered for ${t.id}`);
                        setShowCalibModal(false);
                        setTimeout(() => setToastMessage(null), 2500);
                      }}
                      className="px-3.5 py-1.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition"
                    >
                      Certify
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-[#31363a] flex justify-end">
              <button
                type="button"
                onClick={() => setShowCalibModal(false)}
                className="px-5 py-2 rounded-full bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-white text-xs font-bold transition"
              >
                Close Calendar
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Personnel Profile Modal (Button 4) */}
      <ProfileModal
        user={currentUser}
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onSave={(updated) => {
          setCurrentUser(updated);
          setShowProfileModal(false);
          setToastMessage('Personnel credentials and profile saved.');
          setTimeout(() => setToastMessage(null), 2500);
        }}
      />

      {/* Global Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-blue-600 text-white font-semibold px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2 text-xs border border-blue-400">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
