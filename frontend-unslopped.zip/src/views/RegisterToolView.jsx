import React, { useState } from 'react';
import { api } from '../api';

export default function RegisterToolView({ onToolRegistered, onCancel, user }) {
  const [formData, setFormData] = useState({
    name: '',
    type: 'Power Tool',
    serial_number: '',
    department: user?.department || 'Assembly',
    location: 'Tool Crib A - Shelf 1',
    owner: user?.full_name || '',
    condition: 'New',
    maintenance_due_date: '',
    expected_return_date: '',
    notes: 'Initial tool registration into workshop database.'
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const toolTypes = [
    'Power Tool',
    'Measuring Instrument',
    'Precision Hand Tool',
    'Heavy Machinery',
    'Pneumatic Tool',
    'Welding Equipment',
    'Electrical Testing',
    'General Workshop Tool'
  ];

  const departments = [
    'Assembly',
    'Quality Assurance',
    'Maintenance',
    'Fabrication',
    'Machining',
    'Carpentry & Crating',
    'Shop Management'
  ];

  const conditions = ['New', 'Good', 'Fair'];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.serial_number.trim()) {
      setError('Tool Name and Serial / Batch Number are required.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.registerTool(formData);
      onToolRegistered(res.tool.id);
    } catch (err) {
      setError(err.message || 'Failed to register tool.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 sm:px-6">
      <div className="bg-[#181b1e] border border-[#31363a] rounded-lg shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="bg-[#1e2226] border-b border-[#31363a] text-white px-7 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-space tracking-tight text-white">Register New Workshop Tool</h1>
            <p className="text-xs text-slate-400 mt-1">
              Tool ID and QR code identifier will be generated automatically upon submission.
            </p>
          </div>
          <button
            onClick={onCancel}
            className="text-xs bg-[#121416] hover:bg-[#272c30] text-slate-200 px-4 py-2 rounded-full border border-[#31363a] transition font-medium"
          >
            Cancel
          </button>
        </div>

        {error && (
          <div className="mx-7 mt-6 bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-7 space-y-5 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Tool Name */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Tool Name / Model Description *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="e.g. Bosch 18V Cordless Impact Driver"
                required
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Tool Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Equipment Category *
              </label>
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
              >
                {toolTypes.map(t => (
                  <option key={t} value={t} className="bg-[#121416] text-white">{t}</option>
                ))}
              </select>
            </div>

            {/* Serial or Batch Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Serial or Batch Number *
              </label>
              <input
                type="text"
                name="serial_number"
                value={formData.serial_number}
                onChange={handleChange}
                placeholder="e.g. SN-BOS-98214"
                required
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Department */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Assigned Department *
              </label>
              <select
                name="department"
                value={formData.department}
                onChange={handleChange}
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
              >
                {departments.map(d => (
                  <option key={d} value={d} className="bg-[#121416] text-white">{d}</option>
                ))}
              </select>
            </div>

            {/* Home / Intake Location */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Storage Rack / Home Location *
              </label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleChange}
                placeholder="e.g. Tool Crib A - Shelf 2"
                required
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Tool Custodian / Owner */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Designated Custodian / Owner
              </label>
              <input
                type="text"
                name="owner"
                value={formData.owner}
                onChange={handleChange}
                placeholder="e.g. Marcus Vance"
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Initial Physical Condition */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Intake Condition
              </label>
              <select
                name="condition"
                value={formData.condition}
                onChange={handleChange}
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
              >
                {conditions.map(c => (
                  <option key={c} value={c} className="bg-[#121416] text-white">{c}</option>
                ))}
              </select>
            </div>

            {/* Calibration / Maintenance Due Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Next Calibration / Maintenance Date
              </label>
              <input
                type="date"
                name="maintenance_due_date"
                value={formData.maintenance_due_date}
                onChange={handleChange}
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">Optional: used for periodic calibration alerts</span>
            </div>

            {/* Expected Return Date (if pre-issuing) */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Expected Return Date
              </label>
              <input
                type="date"
                name="expected_return_date"
                value={formData.expected_return_date}
                onChange={handleChange}
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">Leave blank if tool remains in crib storage</span>
            </div>
          </div>

          {/* Registration Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">
              Intake Notes & Inspection Comments
            </label>
            <textarea
              name="notes"
              rows={3}
              value={formData.notes}
              onChange={handleChange}
              placeholder="e.g. PO number, supplier invoice details, physical unboxing comments"
              className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-[#31363a] flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 rounded-full border border-[#31363a] text-xs font-medium text-slate-300 hover:text-white hover:bg-[#1e2226] transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition disabled:opacity-50"
            >
              {loading ? 'Registering Tool...' : 'Register Tool & Generate QR'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
