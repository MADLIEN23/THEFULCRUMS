import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { getStatusStyle } from '../utils/statusColors';

export default function ToolDetailView({ toolId, user, onBack }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Status update modal state
  const [showEventModal, setShowEventModal] = useState(false);
  const [modalStatus, setModalStatus] = useState('In Use');
  const [modalLocation, setModalLocation] = useState('');
  const [modalNotes, setModalNotes] = useState('');
  const [modalExpectedReturn, setModalExpectedReturn] = useState('');
  const [modalMaintenanceFlag, setModalMaintenanceFlag] = useState(false);
  const [modalPhoto, setModalPhoto] = useState(null);
  const [submittingEvent, setSubmittingEvent] = useState(false);
  const [modalError, setModalError] = useState(null);

  const fetchTool = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getTool(toolId);
      setData(res);
      setModalLocation(res.tool.current_location || res.tool.home_location);
    } catch (err) {
      setError(err.message || 'Failed to load tool details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTool();
  }, [toolId]);

  const handlePrintLabel = () => {
    window.print();
  };

  const handleOpenEventModal = () => {
    if (!data) return;
    const current = data.tool.current_status;
    let nextStatus = 'In Use';

    if (current === 'Registered') nextStatus = 'Received';
    else if (current === 'Received') nextStatus = 'Inspected';
    else if (current === 'Inspected') nextStatus = 'Issued';
    else if (current === 'Issued') nextStatus = 'In Use';
    else if (current === 'In Use') nextStatus = 'Returned';
    else if (current === 'Returned') nextStatus = data.tool.maintenance_flag ? 'Sent for Maintenance' : 'Issued';
    else if (current === 'Sent for Maintenance') nextStatus = 'Repaired';
    else if (current === 'Repaired') nextStatus = 'Inspected';

    setModalStatus(nextStatus);
    setModalLocation(data.tool.current_location);
    setModalNotes('');
    setModalExpectedReturn('');
    setModalMaintenanceFlag(false);
    setModalPhoto(null);
    setModalError(null);
    setShowEventModal(true);
  };

  const handleEventSubmit = async (e) => {
    e.preventDefault();
    setSubmittingEvent(true);
    setModalError(null);

    try {
      const formData = new FormData();
      formData.append('status', modalStatus);
      formData.append('location', modalLocation);
      formData.append('notes', modalNotes);
      formData.append('maintenance_flag', modalMaintenanceFlag ? '1' : '0');
      if (modalStatus === 'Issued' && modalExpectedReturn) {
        formData.append('expected_return_date', modalExpectedReturn);
      }
      if (modalPhoto) {
        formData.append('photo', modalPhoto);
      }

      await api.addEvent(toolId, formData);
      setShowEventModal(false);
      await fetchTool();
    } catch (err) {
      setModalError(err.message || 'Failed to update status.');
    } finally {
      setSubmittingEvent(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-12 px-4 text-center">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-slate-300 border-t-blue-600 mb-3"></div>
        <p className="text-sm font-medium text-slate-600">Retrieving asset data and audit records...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-3xl mx-auto py-12 px-4">
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-6 rounded-md">
          <h2 className="text-base font-bold mb-2">Unable to Load Tool Profile</h2>
          <p className="text-sm mb-4">{error || 'Asset not found in database.'}</p>
          <button
            onClick={onBack}
            className="bg-blue-600 text-white text-xs px-4 py-2 rounded-md hover:bg-blue-500 font-semibold transition"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const { tool, qr_code, history } = data;
  const statusStyle = getStatusStyle(tool.current_status);
  const today = new Date().toISOString().split('T')[0];

  const isOverdue = ['Issued', 'In Use'].includes(tool.current_status) && tool.expected_return_date && tool.expected_return_date < today;
  const isAwaitingInspection = ['Registered', 'Received'].includes(tool.current_status);
  const isMaintenanceDue = tool.maintenance_flag === 1 || tool.current_status === 'Sent for Maintenance' || (tool.maintenance_due_date && tool.maintenance_due_date < today);

  const statuses = [
    'Registered',
    'Received',
    'Inspected',
    'Issued',
    'In Use',
    'Returned',
    'Sent for Maintenance',
    'Repaired',
    'Retired'
  ];

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-7">
      {/* Top Header Navigation */}
      <div className="flex items-center justify-between no-print">
        <button
          onClick={onBack}
          className="text-xs bg-[#1e2226] hover:bg-[#272c30] text-white px-4 py-2 rounded-full border border-[#31363a] font-semibold transition flex items-center space-x-2"
        >
          <span>← Back to Fleet</span>
        </button>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={handlePrintLabel}
            className="bg-[#1e2226] hover:bg-[#272c30] text-slate-200 text-xs font-semibold px-4 py-2 rounded-full border border-[#31363a] transition"
          >
            Print Asset Label
          </button>
          <button
            onClick={handleOpenEventModal}
            className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-5 py-2 rounded-full transition"
          >
            + Log Status Event
          </button>
        </div>
      </div>

      {/* Red Flag Warning Banners */}
      {tool.maintenance_flag === 1 && (
        <div className="bg-rose-950/40 border border-rose-500/40 p-5 rounded-lg text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-rose-300 font-mono">
                Alert: Maintenance Required - Tool Unavailable
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                This tool was returned with reported damage or defects. It is marked as unavailable for checkout until an inspection and repair event are logged.
              </p>
            </div>
            <span className="px-3 py-1 text-xs font-bold bg-rose-600/30 text-rose-200 border border-rose-500/40 rounded-full font-mono">
              UNAVAILABLE
            </span>
          </div>
        </div>
      )}

      {isOverdue && (
        <div className="bg-amber-950/40 border border-amber-500/40 p-5 rounded-lg text-white">
          <h3 className="text-xs font-bold text-amber-300 font-mono">
            Warning: Overdue Return
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            This tool was checked out and expected back on <strong className="text-amber-200">{tool.expected_return_date}</strong>. Contact custodian <strong className="text-white">{tool.owner}</strong>.
          </p>
        </div>
      )}

      {isAwaitingInspection && (
        <div className="bg-sky-950/40 border border-sky-500/40 p-5 rounded-lg text-white">
          <h3 className="text-xs font-bold text-sky-300 font-mono">
            Quality Inspection Required
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            Tool is currently in <strong className="text-sky-200">{tool.current_status}</strong> state. It must undergo quality verification by an Inspector before being issued.
          </p>
        </div>
      )}

      {/* Main Grid: Tool Profile Card and Printable QR Label */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tool Specification Card (2 cols) */}
        <div className="lg:col-span-2 bg-[#181b1e] border border-[#31363a] rounded-lg shadow-2xl p-7 text-white">
          <div className="flex flex-wrap items-start justify-between pb-5 border-b border-[#31363a] gap-3">
            <div>
              <div className="flex items-center space-x-2.5">
                <span className="font-mono font-bold text-blue-400 text-xs bg-blue-500/15 px-3 py-1 rounded-full border border-blue-500/30">
                  {tool.id}
                </span>
                <h1 className="text-2xl font-bold font-space text-white">{tool.name}</h1>
              </div>
              <p className="text-xs text-slate-400 mt-1.5">
                Category: <span className="font-semibold text-slate-200">{tool.type}</span> • Registered on {new Date(tool.created_at).toLocaleDateString()}
              </p>
            </div>

            {/* Current Status Pill */}
            <div className="text-right">
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
                <span className={`w-2 h-2 rounded-full mr-1.5 ${statusStyle.dot}`}></span>
                {tool.current_status}
              </span>
              <div className="text-[11px] text-slate-400 mt-1 font-mono">
                Updated {new Date(tool.last_updated_at).toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Specifications Table */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-5 text-sm">
            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Serial / Batch Number</span>
              <span className="font-mono font-semibold text-white">{tool.serial_number}</span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Assigned Department</span>
              <span className="font-medium text-slate-200">{tool.department}</span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Current Bay / Location</span>
              <span className="font-medium text-slate-200">{tool.current_location}</span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Home Storage Rack</span>
              <span className="font-medium text-slate-200">{tool.home_location}</span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Custodian / Assigned Worker</span>
              <span className="font-medium text-slate-200">{tool.owner}</span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Initial Condition</span>
              <span className="font-medium text-slate-200">{tool.initial_condition}</span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Expected Return Date</span>
              <span className={`font-medium ${isOverdue ? 'text-rose-400 font-bold' : 'text-slate-200'}`}>
                {tool.expected_return_date || 'N/A (In Storage)'}
              </span>
            </div>

            <div className="border border-[#31363a] p-4 rounded-lg bg-[#1e2226]">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Maintenance / Calibration Due</span>
              <span className={`font-medium ${tool.maintenance_due_date && tool.maintenance_due_date < today ? 'text-rose-400 font-bold' : 'text-slate-200'}`}>
                {tool.maintenance_due_date || 'N/A'}
              </span>
            </div>
          </div>
        </div>

        {/* Printable QR Code Label (1 col) */}
        <div id="printable-qr-label" className="bg-[#181b1e] border border-[#31363a] rounded-lg p-6 flex flex-col items-center justify-center text-center shadow-2xl text-white">
          <div className="border-b border-[#31363a] w-full pb-3 mb-4">
            <span className="text-[11px] font-bold text-slate-400 block">ToolTrack Workshop Tag</span>
            <span className="font-mono text-xl font-bold text-blue-400">{tool.id}</span>
          </div>

          {qr_code && (
            <div className="p-3 bg-white rounded-lg mb-4">
              <img
                src={qr_code}
                alt={`QR code for ${tool.id}`}
                className="w-44 h-44 rounded-lg object-contain"
              />
            </div>
          )}

          <div className="text-xs text-slate-300 w-full space-y-1">
            <p className="font-bold text-white text-sm truncate">{tool.name}</p>
            <p className="font-mono text-[11px] text-slate-400">SN: {tool.serial_number}</p>
            <p className="text-[11px] text-slate-400">{tool.department} • {tool.home_location}</p>
          </div>

          <p className="text-[10px] text-slate-500 mt-4 pt-3 border-t border-[#31363a] w-full no-print">
            Scan with any mobile terminal to view equipment status
          </p>
        </div>
      </div>

      {/* Visual Audit History Timeline */}
      <div className="bg-[#181b1e] border border-[#31363a] rounded-lg shadow-2xl p-7 text-white">
        <div className="border-b border-[#31363a] pb-4 mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold font-space text-white">Immutable Audit History Timeline</h2>
            <p className="text-xs text-slate-400 mt-1">
              Every status change is permanently recorded in SQLite. Records cannot be overwritten or deleted.
            </p>
          </div>
          <span className="text-xs bg-[#1e2226] text-slate-300 px-3 py-1 rounded-full font-mono font-medium border border-[#31363a]">
            {history.length} Event{history.length === 1 ? '' : 's'}
          </span>
        </div>

        {/* Vertical Timeline */}
        <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-2.5 sm:before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#31363a]">
          {history.map((event, index) => {
            const evStyle = getStatusStyle(event.status);
            const isLatest = index === 0;

            return (
              <div key={event.id} className="relative group">
                {/* Timeline node circle */}
                <div className={`absolute -left-6 sm:-left-8 top-1.5 w-4 h-4 rounded-full border-2 border-[#181b1e] flex items-center justify-center ${evStyle.dot}`}>
                </div>

                {/* Event Card */}
                <div className={`rounded-lg p-5 transition border ${isLatest ? 'border-blue-500/40 bg-[#1e2226]' : 'border-[#31363a] bg-[#1e2226]'}`}>
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div className="flex items-center space-x-2">
                      <span className={`px-2.5 py-0.5 text-xs font-semibold rounded-full border ${evStyle.bg} ${evStyle.text} ${evStyle.border}`}>
                        {event.status}
                      </span>
                      {isLatest && (
                        <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full font-mono">
                          Current
                        </span>
                      )}
                      {event.maintenance_flag === 1 && (
                        <span className="bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full font-mono">
                          Maintenance Flagged
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-400 font-mono">
                      {new Date(event.timestamp).toLocaleString()}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300 mb-2">
                    <div>
                      <span className="font-semibold text-slate-400">Logged By:</span> {event.updated_by}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-400">Location:</span> {event.location}
                    </div>
                  </div>

                  {event.notes && (
                    <div className="mt-3 text-xs text-slate-200 bg-[#181b1e] border border-[#31363a] rounded-md p-3">
                      <span className="font-semibold text-slate-400 block mb-1">Notes:</span>
                      {event.notes}
                    </div>
                  )}

                  {event.photo && (
                    <div className="mt-4">
                      <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
                        Attached Inspection Photograph:
                      </span>
                      <img
                        src={event.photo}
                        alt="Inspection photograph"
                        className="max-h-48 rounded-md border border-[#31363a] object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Status Update Modal */}
      {showEventModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-[#181b1e] rounded-lg shadow-2xl max-w-lg w-full border border-[#31363a] overflow-hidden text-white">
            <div className="bg-[#1e2226] px-6 py-4 flex items-center justify-between border-b border-[#31363a]">
              <div>
                <h3 className="text-base font-bold font-space text-white">Log Tool Lifecycle Event</h3>
                <p className="text-xs text-blue-400 font-mono mt-0.5">{tool.id} - {tool.name}</p>
              </div>
              <button
                onClick={() => setShowEventModal(false)}
                className="w-7 h-7 rounded-full bg-white/[0.08] hover:bg-white/[0.16] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>

            {modalError && (
              <div className="mx-6 mt-4 bg-rose-950/50 border border-rose-500/40 text-rose-300 text-xs px-4 py-2.5 rounded-md">
                {modalError}
              </div>
            )}

            <form onSubmit={handleEventSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Transition Status To *
                </label>
                <select
                  value={modalStatus}
                  onChange={(e) => setModalStatus(e.target.value)}
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                >
                  {statuses.map(s => (
                    <option key={s} value={s} className="bg-[#121416] text-white">{s}</option>
                  ))}
                </select>
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Inspected and Repaired require Inspector role. Retired requires Admin role.
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Current Location *
                </label>
                <input
                  type="text"
                  value={modalLocation}
                  onChange={(e) => setModalLocation(e.target.value)}
                  placeholder="e.g. Bay 3, Tool Crib A, QC Calibration Bench"
                  required
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {modalStatus === 'Issued' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                    Expected Return Date
                  </label>
                  <input
                    type="date"
                    value={modalExpectedReturn}
                    onChange={(e) => setModalExpectedReturn(e.target.value)}
                    className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
              )}

              {modalStatus === 'Returned' && (
                <div className="bg-[#1e2226] border border-rose-500/30 p-4 rounded-lg">
                  <label className="flex items-center space-x-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={modalMaintenanceFlag}
                      onChange={(e) => setModalMaintenanceFlag(e.target.checked)}
                      className="w-4 h-4 text-rose-500 rounded accent-rose-500"
                    />
                    <span className="text-xs font-bold text-rose-400">
                      Mark as "Maintenance Required" (Defective or Damaged)
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-400 mt-1 pl-6">
                    Checking this flags the tool as Unavailable in the dashboard until a repair is verified.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Inspection / Transition Notes
                </label>
                <textarea
                  rows={3}
                  value={modalNotes}
                  onChange={(e) => setModalNotes(e.target.value)}
                  placeholder="Describe tool condition, work order numbers, or observed wear..."
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Optional Photo (Verification / Damage Inspection)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setModalPhoto(e.target.files[0] || null)}
                  className="block w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-white/[0.08] file:text-white hover:file:bg-white/[0.14]"
                />
              </div>

              <div className="pt-4 border-t border-[#31363a] flex justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowEventModal(false)}
                  className="px-4 py-2 rounded-full border border-[#31363a] text-slate-300 hover:text-white hover:bg-white/[0.06] font-medium transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingEvent}
                  className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-semibold transition disabled:opacity-50"
                >
                  {submittingEvent ? 'Recording...' : 'Commit Event to Audit Log'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
