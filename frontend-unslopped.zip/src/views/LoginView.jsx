import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { api } from '../api';
import { Wrench, AlertCircle, Eye, EyeOff, Loader2 } from 'lucide-react';

const DEMO_ACCOUNTS = [
  { username: 'admin', role: 'Admin', name: 'Alex Rivera' },
  { username: 'operator', role: 'Operator', name: 'Marcus V.' },
  { username: 'inspector', role: 'Inspector', name: 'Sarah C.' },
];

// A sample asset tag: shows what the app produces, using the same QR format the scanner reads.
function SampleTag() {
  const [qr, setQr] = useState('');

  useEffect(() => {
    QRCode.toDataURL('TL-1001', { margin: 0, width: 240, color: { dark: '#141618', light: '#f1efea' } })
      .then(setQr)
      .catch(() => setQr(''));
  }, []);

  const rows = [
    ['Tool', 'Torque wrench, 20 to 100 Nm'],
    ['Bay', 'Assembly cell 3'],
    ['Last calibrated', '12 Oct 2026'],
    ['Next due', '10 Jan 2027'],
  ];

  return (
    <figure className="w-full max-w-md rounded-lg border border-[#3a4045] bg-[#1e2226] overflow-hidden" aria-label="Sample tool tag">
      <div className="flex items-stretch">
        <div className="p-5 bg-[#f1efea] flex items-center">
          {qr ? (
            <img src={qr} alt="QR code for TL-1001" className="w-28 h-28" />
          ) : (
            <div className="w-28 h-28" />
          )}
        </div>
        <div className="flex-1 p-5 flex flex-col justify-between min-w-0">
          <div>
            <div className="font-mono text-2xl text-white leading-none">TL-1001</div>
            <div className="mt-2 inline-flex items-center gap-1.5 text-xs text-emerald-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              In use
            </div>
          </div>
          <div className="text-xs text-slate-400">Scan to log checkout, return or inspection.</div>
        </div>
      </div>
      <dl className="border-t border-[#31363a] divide-y divide-[#31363a] text-sm">
        {rows.map(([k, v]) => (
          <div key={k} className="flex justify-between gap-4 px-5 py-2.5">
            <dt className="text-slate-400">{k}</dt>
            <dd className="text-slate-100 text-right">{v}</dd>
          </div>
        ))}
      </dl>
      <figcaption className="px-5 py-2 border-t border-[#31363a] text-xs text-slate-500">Sample tag</figcaption>
    </figure>
  );
}

export default function LoginView({ onLoginSuccess, user, onNavigate }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    if (!username || !password) {
      setError('Enter your username and password.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await api.login(username, password);
      onLoginSuccess(res.user);
    } catch (err) {
      setError(err.message || 'Sign-in failed. Check your username and password.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = (u) => {
    setUsername(u);
    setPassword('password123');
    setLoading(true);
    setError(null);
    api.login(u, 'password123')
      .then((res) => onLoginSuccess(res.user))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  const inputClass =
    'h-11 w-full rounded-md border border-[#3a4045] bg-[#141618] px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400';

  return (
    <div className="min-h-screen bg-[#121416] text-slate-100 font-sans flex flex-col">
      <header className="max-w-6xl w-full mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-md bg-blue-500 flex items-center justify-center">
            <Wrench className="w-4 h-4 text-[#17140b]" />
          </div>
          <span className="font-space font-semibold text-xl text-white">ToolTrack</span>
        </div>
        {user && (
          <button
            onClick={() => (onNavigate ? onNavigate('dashboard') : (window.location.href = '/'))}
            className="text-sm px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-500 text-white"
          >
            Open dashboard
          </button>
        )}
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-6 pt-8 pb-16 grid grid-cols-1 lg:grid-cols-[1.15fr_1fr] gap-14 items-center">
        <section>
          <h1 className="font-space font-semibold text-5xl sm:text-6xl leading-[1.02] text-white max-w-xl">
            Every tool has a tag. Every tag has a history.
          </h1>
          <p className="mt-5 max-w-md text-slate-300 leading-relaxed">
            Scan a tool to see who has it, when it was last calibrated, and what was done to it. Checkouts,
            inspections and repairs are logged as they happen.
          </p>
          <div className="mt-10">
            <SampleTag />
          </div>
        </section>

        <section className="w-full max-w-md lg:justify-self-end">
          <div className="rounded-lg border border-[#31363a] bg-[#181b1e] p-7">
            <h2 className="font-space font-semibold text-2xl text-white">Sign in</h2>

            {error && (
              <div role="alert" className="mt-4 flex items-start gap-2 rounded-md border border-rose-500/40 bg-rose-950/40 px-3.5 py-2.5 text-sm text-rose-200">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <div>
                <label htmlFor="username" className="block text-sm text-slate-300 mb-1.5">Username</label>
                <input
                  id="username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className={inputClass}
                />
              </div>
              <div>
                <label htmlFor="password" className="block text-sm text-slate-300 mb-1.5">Password</label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={`${inputClass} pr-11`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-3 top-3 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 rounded-md bg-blue-500 hover:bg-blue-400 text-[#17140b] font-semibold text-sm disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {loading ? (<><Loader2 className="w-4 h-4 animate-spin" /> Signing in</>) : 'Sign in'}
              </button>
            </form>

            <div className="mt-7 pt-5 border-t border-[#31363a]">
              <p className="text-sm text-slate-400">
                Demo accounts all use the password <code className="font-mono text-blue-300">password123</code>.
              </p>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {DEMO_ACCOUNTS.map((a) => (
                  <button
                    key={a.username}
                    type="button"
                    onClick={() => handleQuickLogin(a.username)}
                    disabled={loading}
                    className="rounded-md border border-[#3a4045] hover:border-blue-400 px-2 py-2 text-left disabled:opacity-60"
                  >
                    <span className="block text-sm text-white">{a.role}</span>
                    <span className="block text-xs text-slate-400">{a.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="max-w-6xl w-full mx-auto px-6 py-6 text-sm text-slate-500 flex gap-5">
        <span>ToolTrack</span>
        <button onClick={() => onNavigate && onNavigate('privacy')} className="hover:text-slate-300">Privacy</button>
        <button onClick={() => onNavigate && onNavigate('terms')} className="hover:text-slate-300">Terms</button>
      </footer>
    </div>
  );
}
