import React from 'react';
import { ArrowLeft, FileText } from 'lucide-react';

export default function TermsConditionsView({ onBack }) {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6">
      <div className="bg-[#121416] border border-[#31363a] rounded-lg p-8 sm:p-10 shadow-2xl">
        <button
          onClick={onBack}
          className="text-xs bg-black hover:bg-[#121416] text-white/90 px-4 py-2 rounded-full border border-[#31363a] font-medium mb-8 inline-flex items-center space-x-2 transition-all"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-red-500" />
          <span>Back to Application</span>
        </button>

        <div className="flex items-center gap-3 border-b border-[#31363a] pb-4 mb-8">
          <div className="w-10 h-10 rounded-md bg-red-600/10 border border-red-600/30 flex items-center justify-center text-red-500">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white font-space">
              ToolTrack Terms and Conditions of Equipment Use
            </h1>
            <p className="text-xs text-slate-400 mt-1">Shopfloor Custody, Equipment Handling & Calibration Governance</p>
          </div>
        </div>

        <div className="space-y-6 text-sm text-slate-300 leading-relaxed font-sans">
          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">1. Equipment Custody and Responsibility</h2>
            <p>
              By checking out a tool under your user account, you accept custody and responsibility for the proper handling, operation, and return of the equipment in accordance with manufacturer guidelines and workshop safety protocols.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">2. Mandatory Damage and Defect Reporting</h2>
            <p>
              Any drop, impact, abnormal vibration, electrical fault, or physical damage occurring during operation must be reported immediately upon return by checking the "Maintenance Required" flag in the tool return terminal. Operating or returning damaged tools without notification is strictly prohibited.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">3. Role-Based Approvals</h2>
            <p>
              Quality calibrations and formal return-to-service sign-offs must only be performed by certified Quality Inspectors or Shop Administrators. Bypassing inspection requirements compromises workplace safety and invalidates calibration certifications.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">4. QR Asset Label Integrity</h2>
            <p>
              All equipment must display an intact, legible ToolTrack QR asset tag. If a tag becomes illegible due to wear or chemical exposure, the custodian must print and affix a replacement tag from the tool detail screen.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">5. Overdue Equipment Returns</h2>
            <p>
              Tools checked out with an expected return date must be returned on or before the specified date. Overdue items trigger automated fleet notifications to department supervisors.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
