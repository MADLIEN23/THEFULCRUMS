import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';

export default function QRScannerView({ onToolDetected, onCancel }) {
  const [scannerActive, setScannerActive] = useState(false);
  const [manualId, setManualId] = useState('');
  const [error, setError] = useState(null);
  const [info, setInfo] = useState('');
  const html5QrCodeRef = useRef(null);

  const parseToolId = (decodedText) => {
    // Check if the decoded string contains a full URL e.g. http://localhost:5173/tools/TL-1001
    const urlMatch = decodedText.match(/\/tools\/([A-Za-z0-9_-]+)/i);
    if (urlMatch && urlMatch[1]) {
      return urlMatch[1].toUpperCase();
    }
    // Check if it's a direct Tool ID e.g. TL-1001
    const directMatch = decodedText.match(/TL-\d+/i);
    if (directMatch) {
      return directMatch[0].toUpperCase();
    }
    return decodedText.trim().toUpperCase();
  };

  const handleScanSuccess = (decodedText) => {
    const toolId = parseToolId(decodedText);
    stopScanner();
    onToolDetected(toolId);
  };

  const startCamera = async () => {
    setError(null);
    setInfo('Requesting camera permissions...');

    try {
      if (html5QrCodeRef.current) {
        await stopScanner();
      }

      const qrCode = new Html5Qrcode('qr-reader-container');
      html5QrCodeRef.current = qrCode;

      const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 }
      };

      await qrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          handleScanSuccess(decodedText);
        },
        () => {
          // Frame scan error callback (ignored during active scanning)
        }
      );

      setScannerActive(true);
      setInfo('Align the tool QR code within the targeting box.');
    } catch (err) {
      console.error('Camera initialization error:', err);
      setError('Unable to access video camera. You can scan an image file or enter the Tool ID manually below.');
      setScannerActive(false);
      setInfo('');
    }
  };

  const stopScanner = async () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      } catch (err) {
        console.error('Error stopping QR scanner:', err);
      }
    }
    setScannerActive(false);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setError(null);
    setInfo('Processing QR code image...');

    try {
      const qrCode = new Html5Qrcode('qr-reader-container');
      const result = await qrCode.scanFile(file, true);
      handleScanSuccess(result);
    } catch (err) {
      console.error('Image scan error:', err);
      setError('No legible QR code found in the selected image. Please try another image or enter the ID manually.');
      setInfo('');
    }
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (!manualId.trim()) return;
    onToolDetected(manualId.trim().toUpperCase());
  };

  useEffect(() => {
    return () => {
      // Clean up camera stream when component unmounts
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch(() => {});
      }
    };
  }, []);

  return (
    <div className="max-w-2xl mx-auto py-10 px-4 sm:px-6">
      <div className="bg-[#181b1e] border border-[#31363a] rounded-lg shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="bg-[#1e2226] border-b border-[#31363a] text-white px-7 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-space tracking-tight text-white">QR Asset Code Scanner</h1>
            <p className="text-xs text-slate-400 mt-1">
              Scan tool barcode label to open live status, timeline, and actions.
            </p>
          </div>
          <button
            onClick={() => {
              stopScanner();
              onCancel();
            }}
            className="text-xs bg-[#121416] hover:bg-[#272c30] text-slate-200 px-4 py-2 rounded-full border border-[#31363a] transition font-medium"
          >
            Close
          </button>
        </div>

        <div className="p-7 space-y-6">
          {error && (
            <div className="bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          {info && !error && (
            <div className="bg-blue-950/40 border border-blue-500/40 text-blue-300 text-xs px-4 py-3 rounded-lg">
              {info}
            </div>
          )}

          {/* Scanner Viewport */}
          <div className="border border-[#31363a] rounded-lg bg-[#121416] p-5 min-h-[300px] flex flex-col items-center justify-center relative">
            <div id="qr-reader-container" className="w-full max-w-[320px] rounded-md overflow-hidden"></div>

            {!scannerActive && (
              <div className="text-center py-8">
                <div className="w-12 h-12 bg-blue-500/15 text-blue-400 rounded-lg mx-auto flex items-center justify-center mb-3 border border-blue-500/30">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <p className="text-sm font-semibold text-white">Camera Scanner Inactive</p>
                <p className="text-xs text-slate-400 mt-1 mb-5">Click below to activate laptop camera or mobile lens</p>
                <button
                  type="button"
                  onClick={startCamera}
                  className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-6 py-2.5 rounded-full transition"
                >
                  Activate Live Camera
                </button>
              </div>
            )}

            {scannerActive && (
              <div className="mt-4">
                <button
                  type="button"
                  onClick={stopScanner}
                  className="bg-[#1e2226] hover:bg-[#272c30] text-slate-200 text-xs font-semibold px-4 py-2 rounded-full border border-[#31363a] transition"
                >
                  Stop Camera Stream
                </button>
              </div>
            )}
          </div>

          {/* Alternative Scan Methods */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-[#31363a]">
            {/* Image File Upload */}
            <div className="border border-[#31363a] rounded-lg p-4 bg-[#1e2226]">
              <span className="block text-xs font-semibold text-slate-300 mb-1">
                Scan From QR Image File
              </span>
              <p className="text-xs text-slate-400 mb-3">
                Upload a photo or screenshot of a tool QR label
              </p>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="block w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-white/[0.08] file:text-white hover:file:bg-white/[0.14] cursor-pointer"
              />
            </div>

            {/* Direct Tool ID Key-in */}
            <div className="border border-[#31363a] rounded-lg p-4 bg-[#1e2226]">
              <span className="block text-xs font-semibold text-slate-300 mb-1">
                Manual Tool ID Entry
              </span>
              <p className="text-xs text-slate-400 mb-3">
                Enter asset code directly (e.g. TL-1001)
              </p>
              <form onSubmit={handleManualSubmit} className="flex space-x-2">
                <input
                  type="text"
                  value={manualId}
                  onChange={(e) => setManualId(e.target.value)}
                  placeholder="TL-1001"
                  className="flex-1 px-3.5 py-1.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-1.5 rounded-md transition"
                >
                  Open
                </button>
              </form>
            </div>
          </div>

          {/* Quick Select Preset Tools for Demo */}
          <div className="bg-[#1e2226] rounded-lg p-4 border border-[#31363a]">
            <span className="text-xs font-semibold text-slate-400 block mb-2.5 font-mono">
              Fast Demo Jump (Click any tool to simulate scan)
            </span>
            <div className="flex flex-wrap gap-2">
              {['TL-1001', 'TL-1002', 'TL-1003', 'TL-1004', 'TL-1005', 'TL-1006', 'TL-1007', 'TL-1008', 'TL-1009', 'TL-1010'].map(id => (
                <button
                  key={id}
                  onClick={() => onToolDetected(id)}
                  className="bg-[#121416] hover:bg-blue-600 hover:text-white text-slate-300 text-xs font-mono font-semibold px-3 py-1 rounded-full border border-[#31363a] transition"
                >
                  {id}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
