import React from 'react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';

export default function PrivacyPolicyView({ onBack }) {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6">
      <div className="bg-[#121416] border border-[#31363a] rounded-lg p-8 sm:p-10 shadow-2xl">
        <button
          onClick={onBack}
          className="text-xs bg-black hover:bg-[#121416] text-white/90 px-4 py-2 rounded-full border border-[#31363a] font-medium mb-8 inline-flex items-center space-x-2 transition-all"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-red-500" />
          <span>Back to Application</span>
        </button>

        <div className="flex items-center gap-3 border-b border-[#31363a] pb-4 mb-8">
          <div className="w-10 h-10 rounded-md bg-red-600/10 border border-red-600/30 flex items-center justify-center text-red-500">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white font-space">
              ToolTrack Workshop Privacy Policy
            </h1>
            <p className="text-xs text-slate-400 mt-1">Enterprise Industrial Data Governance & Audit Log Retention</p>
          </div>
        </div>

        <div className="space-y-6 text-sm text-slate-300 leading-relaxed font-sans">
          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">1. Operational Scope</h2>
            <p>
              ToolTrack operates strictly as an internal inventory control and equipment lifecycle tracking system for workshop, plant, and factory operations. We do not sell, rent, or distribute personal identity information to third parties.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">2. Data Collection and Usage</h2>
            <p>
              The system records employee identity data solely for audit logging, chain of custody compliance, and accountability:
            </p>
            <ul className="list-disc pl-5 mt-2 space-y-1.5 text-slate-300">
              <li>Full name, employee role, and assigned plant department.</li>
              <li>Timestamps and physical bay/station locations where equipment transactions take place.</li>
              <li>Inspection photos submitted during intake, damage triage, or calibration.</li>
            </ul>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">3. Immutable Audit Log Policy</h2>
            <p>
              To maintain industrial safety standards and OSHA/ISO-9001 auditability, equipment status event logs are immutable. Records of tool checkouts, returns, inspections, and repairs cannot be altered or purged by line operators.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">4. Data Storage and Security</h2>
            <p>
              Passwords are stored using industry-standard salted cryptographic hashes (bcrypt). All authentication tokens are verified via JSON Web Tokens with finite expiration windows.
            </p>
          </section>

          <section className="bg-white/[0.02] p-5 rounded-md border border-white/[0.05]">
            <h2 className="text-base font-semibold text-white mb-2 font-space">5. Contact and Administration</h2>
            <p>
              Inquiries regarding data retention or access requests should be directed to the plant system administrator at your local facilities office.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
