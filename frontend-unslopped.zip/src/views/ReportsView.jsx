import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { api } from '../api';
import { getStatusStyle } from '../utils/statusColors';

// DiscreteTabs, FilterDisclosure, CommandSearch, ShowQr
import { DiscreteTabs } from '../components/DiscreteTabs';
import { FilterDisclosure } from '../components/FilterDisclosure';
import { CommandSearch } from '../components/CommandSearch';
import { ShowQr } from '../components/ShowQr';

// React-Icons requested by user
import { FaBell, FaTasks } from 'react-icons/fa';
import { IoCalendar } from 'react-icons/io5';
import { BsFillPeopleFill, BsPinFill } from 'react-icons/bs';
import { RiBubbleChartFill } from 'react-icons/ri';
import { HiCalendarDays } from 'react-icons/hi2';
import { MdMailOutline } from 'react-icons/md';

// Lucide Icons
import {
  FileText,
  Download,
  Printer,
  ShieldAlert,
  AlertTriangle,
  Clock,
  Wrench,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  AlertOctagon,
  BarChart3,
  UserCheck,
  Shield,
  Layers,
  ArrowUpRight,
  SlidersHorizontal,
  Calendar,
  LayoutGrid,
  Search,
  Box,
  Copy
} from 'lucide-react';

export default function ReportsView({ onSelectTool }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Active section tab: 'overview', 'defects', 'overdue', 'frequency', 'dormant', 'departments'
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDisclosureFilters, setSelectedDisclosureFilters] = useState([]);
  const [toastMessage, setToastMessage] = useState(null);

  const fetchReports = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getReportsSummary();
      setData(res);
    } catch (err) {
      setError(err.message || 'Failed to load reports data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleDownloadCsv = async () => {
    try {
      const token = api.getToken();
      const res = await fetch('/api/reports/csv', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to generate CSV');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `tooltrack_workshop_fleet_report_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      setToastMessage('Exported official workshop audit report to CSV.');
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err) {
      alert(`Error exporting CSV: ${err.message}`);
    }
  };

  const handlePrintPdf = () => {
    window.print();
  };

  // Disclosure filter items (user's exact requested icons)
  const disclosureFilterItems = [
    { id: 'tasks', label: 'Tasks & Defects', icon: FaTasks },
    { id: 'events', label: 'Overdue Returns', icon: IoCalendar },
    { id: 'reminders', label: 'Maintenance Alerts', icon: FaBell },
    { id: 'appointments', label: 'High-Wear Tools', icon: BsPinFill },
    { id: 'meetings', label: 'Department Audit', icon: BsFillPeopleFill },
    { id: 'celebrations', label: 'Full Executive Ledger', icon: RiBubbleChartFill },
  ];

  // DiscreteTabs options for report sections
  const reportTabs = [
    { id: 'overview', icon: <RiBubbleChartFill size={16} />, label: 'Overview', activeColor: 'text-indigo-400' },
    { id: 'defects', icon: <FaTasks size={16} />, label: 'Defect Dispatch', activeColor: 'text-rose-400' },
    { id: 'overdue', icon: <IoCalendar size={16} />, label: 'Overdue Register', activeColor: 'text-amber-400' },
    { id: 'frequency', icon: <BsPinFill size={16} />, label: 'High-Wear Leaderboard', activeColor: 'text-yellow-400' },
    { id: 'dormant', icon: <FaBell size={16} />, label: 'Dormant Assets', activeColor: 'text-sky-400' },
    { id: 'departments', icon: <BsFillPeopleFill size={16} />, label: 'Department Audit', activeColor: 'text-emerald-400' },
  ];

  if (loading) {
    return (
      <div className="w-full min-h-screen bg-[#F0F2F6] dark:bg-[#121416] p-6 flex flex-col items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
          className="w-10 h-10 rounded-full border-2 border-indigo-500/20 border-t-indigo-500 mb-4"
        />
        <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
          Loading report data...
        </p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-3xl mx-auto py-16 px-4">
        <div className="bg-[#1e2226] border border-blue-500/30 text-slate-300 p-8 rounded-lg text-center space-y-4 shadow-2xl">
          <div className="w-12 h-12 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-400 flex items-center justify-center mx-auto">
            <LayoutGrid className="w-6 h-6 text-blue-400" />
          </div>
          <h2 className="text-lg font-bold font-space text-white">Audit Telemetry Reconnecting</h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto">{error || 'Compiling plant audit telemetry ledger...'}</p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={fetchReports}
              className="px-5 py-2.5 rounded-full bg-[#272c30] hover:bg-[#3a4045] text-slate-200 border border-[#31363a] text-xs font-bold transition"
            >
              Retry Telemetry Fetch
            </button>
            <button
              onClick={async () => {
                try {
                  await api.login('admin', 'password123');
                  fetchReports();
                } catch (e) {
                  fetchReports();
                }
              }}
              className="px-5 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition"
            >
              Refresh
            </button>
          </div>
        </div>
      </div>
    );
  }

  const {
    summary,
    overdue_items = [],
    maintenance_frequency = [],
    inactive_items = [],
    maintenance_notifications = [],
    department_breakdown = [],
    status_breakdown = []
  } = data;

  // Command Search items compiled from all report sections
  const commandItems = [
    ...overdue_items.map(t => ({
      id: `overdue-${t.id}`,
      title: `${t.id} - ${t.name} (${t.days_overdue}d overdue)`,
      section: 'Overdue Equipment',
      icon: <Clock size={16} className="text-rose-400" />,
      action: () => {
        setActiveTab('overdue');
        if (onSelectTool) onSelectTool(t.id);
      }
    })),
    ...maintenance_notifications.map(t => ({
      id: `defect-${t.id}`,
      title: `${t.id} - ${t.name} (Defect Flagged)`,
      section: 'Defect Dispatch',
      icon: <Wrench size={16} className="text-amber-400" />,
      action: () => {
        setActiveTab('defects');
        if (onSelectTool) onSelectTool(t.id);
      }
    })),
    ...maintenance_frequency.map(t => ({
      id: `freq-${t.id}`,
      title: `${t.id} - ${t.name} (${t.maintenance_events_count} events)`,
      section: 'High-Wear Assets',
      icon: <BarChart3 size={16} className="text-indigo-400" />,
      action: () => {
        setActiveTab('frequency');
        if (onSelectTool) onSelectTool(t.id);
      }
    })),
    ...inactive_items.map(t => ({
      id: `dormant-${t.id}`,
      title: `${t.id} - ${t.name} (${t.days_inactive}d idle)`,
      section: 'Dormant Assets',
      icon: <AlertTriangle size={16} className="text-sky-400" />,
      action: () => {
        setActiveTab('dormant');
        if (onSelectTool) onSelectTool(t.id);
      }
    }))
  ];

  // Search filtering
  const q = searchQuery.toLowerCase().trim();
  const filteredOverdue = overdue_items.filter(i => !q || i.name?.toLowerCase().includes(q) || i.id?.toLowerCase().includes(q) || i.department?.toLowerCase().includes(q));
  const filteredDefects = maintenance_notifications.filter(i => !q || i.name?.toLowerCase().includes(q) || i.id?.toLowerCase().includes(q) || i.reported_by?.toLowerCase().includes(q));
  const filteredFrequency = maintenance_frequency.filter(i => !q || i.name?.toLowerCase().includes(q) || i.id?.toLowerCase().includes(q) || i.department?.toLowerCase().includes(q));
  const filteredInactive = inactive_items.filter(i => !q || i.name?.toLowerCase().includes(q) || i.id?.toLowerCase().includes(q) || i.current_location?.toLowerCase().includes(q));

  return (
    <div className="w-full min-h-screen bg-[#121416] p-3 sm:p-6 lg:p-8 font-sans transition-colors duration-300">
      {/* Outer Shell Window (Matches Precision Sapphire & Obsidian Frame) */}
      <div className="max-w-[1440px] mx-auto bg-[#181b1e] rounded-lg  p-5 sm:p-8 lg:p-10 shadow-2xl border border-[#31363a] space-y-8">
        
        {/* ========================================================================= */}
        {/* 1. TOP HEADER & EXPORT ACTIONS                                            */}
        {/* ========================================================================= */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-6 border-b border-[#31363a]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-space font-extrabold text-lg tracking-tight text-white">
                  THE FULCRUMS <span className="text-blue-400">• TOOLTRACK</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
                  ISO-9001
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Plant Audit Ledger & Equipment Turnaround Analytics</p>
            </div>
          </div>

          {/* Action Buttons: Export CSV & Print PDF */}
          <div className="flex items-center gap-2.5">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleDownloadCsv}
              className="px-4 py-2.5 rounded-full bg-[#1e2226] hover:bg-[#272c30] hover:border-blue-500 text-white text-xs font-bold border border-[#31363a] transition flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-blue-400" />
              <span>Export CSV</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handlePrintPdf}
              className="px-5 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              <span>Print Executive PDF</span>
            </motion.button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. ROW OF 4 ANIMATED METRIC CARDS                                         */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          
          {/* Card 1: Availability */}
          <motion.div
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
            className="bg-[#1e2226] rounded-lg p-6 border border-[#31363a] hover:border-blue-500/40 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-medium">
                <span>Availability</span>
                <span className="w-5 h-5 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-[11px] font-bold">
                  ✓
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-space text-white">
                {summary.available_percentage}%
              </div>
              <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 mt-1">
                <span>{summary.available_tools} of {summary.total_tools}</span>
                <span className="text-slate-400 font-normal">units ready for checkout</span>
              </div>
            </div>

            {/* Shift Density Micro-Bars */}
            <div className="mt-4 pt-2">
              <div className="flex items-end justify-between gap-1.5 h-12">
                {[45, 60, 80, 72, 90, 84, 95].map((h, i) => (
                  <motion.div
                    key={i}
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    transition={{ duration: 0.5, delay: i * 0.05 }}
                    className="flex-1 bg-emerald-500/80 rounded-sm"
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* Card 2: Average Turnaround */}
          <motion.div
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
            className="bg-[#1e2226] rounded-lg p-6 border border-[#31363a] hover:border-blue-500/40 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-medium">
                <span>Average Turnaround</span>
                <div className="w-5 h-5 rounded-full bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Clock className="w-3 h-3" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-space text-white">
                {summary.avg_turnaround_days} <span className="text-base font-normal text-slate-400">Days</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-semibold text-blue-400 mt-1">
                <span>Checkout to return</span>
                <span className="text-slate-400 font-normal">turnaround interval</span>
              </div>
            </div>

            {/* Smooth Blue Wavy Spline */}
            <div className="mt-4 pt-2">
              <svg className="w-full h-12 overflow-visible" viewBox="0 0 160 40">
                <path
                  d="M 5 35 Q 30 30, 50 24 T 90 20 T 130 12 T 155 8"
                  stroke="#3b82f6"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  fill="none"
                />
                {[
                  { cx: 5, cy: 35 },
                  { cx: 50, cy: 24 },
                  { cx: 90, cy: 20 },
                  { cx: 130, cy: 12 },
                  { cx: 155, cy: 8 }
                ].map((pt, idx) => (
                  <circle key={idx} cx={pt.cx} cy={pt.cy} r="3" fill="#ffffff" stroke="#3b82f6" strokeWidth="2" />
                ))}
              </svg>
            </div>
          </motion.div>

          {/* Card 3: Overdue Checkouts */}
          <motion.div
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
            className="bg-[#1e2226] rounded-lg p-6 border border-[#31363a] hover:border-rose-500/40 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-medium">
                <span>Overdue Checkouts</span>
                <span className="w-5 h-5 rounded-full bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 text-[11px] font-bold">
                  !
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-space text-rose-400">
                {summary.overdue_count} <span className="text-base font-normal text-slate-400">Assets</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-semibold text-rose-400 mt-1">
                <span>Supervisor action</span>
                <span className="text-slate-400 font-normal">required for return</span>
              </div>
            </div>

            {/* Workbench Graphic */}
            <div className="mt-4 pt-1 flex items-center justify-center">
              <svg className="w-full h-12 text-slate-600" viewBox="0 0 180 45" fill="none">
                <path d="M 10 38 H 170" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                <rect x="100" y="16" width="35" height="22" rx="2" stroke="#f43f5e" strokeWidth="1.5" fill="#f43f5e" fillOpacity="0.1" />
                <circle cx="50" cy="25" r="8" stroke="#f43f5e" strokeWidth="1.5" />
              </svg>
            </div>
          </motion.div>

          {/* Card 4: Maintenance Alerts */}
          <motion.div
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
            className="bg-[#1e2226] rounded-lg p-6 border border-[#31363a] hover:border-amber-500/40 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-medium">
                <span>Maintenance Alerts</span>
                <div className="w-5 h-5 rounded-full bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500">
                  <Wrench className="w-3 h-3" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-space text-amber-400">
                {summary.maintenance_required_tools} <span className="text-base font-normal text-slate-400">Assets</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 mt-1">
                <span>Needs maintenance</span>
                <span className="text-slate-400 font-normal">awaiting inspection</span>
              </div>
            </div>

            {/* Amber Alert Micro-Bars */}
            <div className="mt-4 pt-2">
              <div className="flex items-end justify-between gap-1.5 h-12">
                {[30, 50, 40, 75, 60, 85, 70].map((h, i) => (
                  <motion.div
                    key={i}
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    transition={{ duration: 0.5, delay: i * 0.05 }}
                    className="flex-1 bg-amber-500/80 rounded-sm"
                  />
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* ========================================================================= */}
        {/* 3. SECTION NAVIGATION (DiscreteTabs + FilterDisclosure + CommandSearch)   */}
        {/* ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-3 flex-wrap">
            {/* User's Exact DiscreteTabs Component */}
            <DiscreteTabs
              tabs={reportTabs}
              defaultTab="overview"
              value={activeTab}
              onChange={(id) => setActiveTab(id)}
              className="bg-[#1e2226] border-[#31363a]"
            />

            {/* User's Exact FilterDisclosure Component */}
            <FilterDisclosure
              items={disclosureFilterItems}
              selectedIds={selectedDisclosureFilters}
              buttonLabel="Filter Ledger"
              onConfirm={(ids) => {
                setSelectedDisclosureFilters(ids);
                if (ids.includes('tasks')) setActiveTab('defects');
                else if (ids.includes('events')) setActiveTab('overdue');
                else if (ids.includes('reminders')) setActiveTab('frequency');
                else if (ids.includes('meetings')) setActiveTab('departments');
              }}
              onReset={() => {
                setSelectedDisclosureFilters([]);
                setSearchQuery('');
                setActiveTab('overview');
              }}
            />
          </div>

          {/* User's Exact CommandSearch Component */}
          <div className="w-full md:w-auto">
            <CommandSearch
              items={commandItems}
              placeholder="Search audit records (⌘ K)..."
              onQueryChange={(q) => setSearchQuery(q)}
            />
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 4. MAIN REPORTS CONTENT SECTIONS WITH SPRING ANIMATIONS                   */}
        {/* ========================================================================= */}
        <div className="bg-[#101214] rounded-lg  p-6 sm:p-8 text-white shadow-2xl border border-[#31363a] space-y-6">
          
          <AnimatePresence mode="wait">
            {/* TAB 1: OVERVIEW & MASTER LEDGER */}
            {activeTab === 'overview' && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                {/* Defect Highlights Ribbon */}
                {filteredDefects.length > 0 && (
                  <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2 text-rose-400 font-bold text-xs font-mono">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                        <span>Defect Dispatch Alerts ({filteredDefects.length})</span>
                      </div>
                      <button
                        onClick={() => setActiveTab('defects')}
                        className="text-xs text-rose-400 hover:text-white font-semibold flex items-center gap-1"
                      >
                        <span>View All</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {filteredDefects.slice(0, 2).map((item) => (
                        <div key={item.id} className="p-3.5 rounded-md bg-[#181b1e] border border-[#31363a] flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-space font-bold text-blue-400 text-xs"># {item.id}</span>
                              <span className="font-semibold text-white text-xs">{item.name}</span>
                            </div>
                            <p className="text-[11px] text-slate-300 mt-1 line-clamp-1">{item.defect_description || 'Tolerance breach'}</p>
                          </div>
                          <button
                            onClick={() => onSelectTool && onSelectTool(item.id)}
                            className="px-3 py-1 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition"
                          >
                            Inspect
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Overdue Items Quick Ledger */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-space font-bold text-base text-white">Overdue Returns Register</h3>
                    <span className="text-xs font-mono text-slate-400">{filteredOverdue.length} items flagged</span>
                  </div>

                  {filteredOverdue.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-400 font-mono bg-[#181b1e] rounded-lg border border-[#31363a]">
                      Zero overdue equipment in current audit scope.
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-lg border border-[#31363a] bg-[#181b1e]">
                      <table className="min-w-full divide-y divide-[#31363a] text-left text-xs">
                        <thead className="bg-[#1e2226] text-slate-300 font-semibold text-[11px] border-b border-[#31363a]">
                          <tr>
                            <th className="py-3 px-4">Tool ID</th>
                            <th className="py-3 px-4">Equipment Name</th>
                            <th className="py-3 px-4">Department</th>
                            <th className="py-3 px-4">Borrower</th>
                            <th className="py-3 px-4">Expected Date</th>
                            <th className="py-3 px-4">Overdue Days</th>
                            <th className="py-3 px-4 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#31363a] text-slate-200">
                          {filteredOverdue.slice(0, 5).map((item) => (
                            <tr key={item.id} className="hover:bg-[#1e2226]/60 transition">
                              <td className="py-3 px-4 font-mono font-bold text-blue-400"># {item.id}</td>
                              <td className="py-3 px-4 font-semibold text-white">{item.name}</td>
                              <td className="py-3 px-4 text-slate-300">{item.department}</td>
                              <td className="py-3 px-4">{item.owner}</td>
                              <td className="py-3 px-4 font-mono text-slate-400">{item.expected_return_date}</td>
                              <td className="py-3 px-4">
                                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30 font-mono">
                                  {item.days_overdue} Days
                                </span>
                              </td>
                              <td className="py-3 px-4 text-right">
                                <button
                                  onClick={() => onSelectTool && onSelectTool(item.id)}
                                  className="px-3 py-1 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition"
                                >
                                  Audit
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Split Metrics: Department & Status Breakdown */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
                  {/* Department Breakdown */}
                  <div className="p-5 rounded-lg bg-[#181b1e] border border-[#31363a] space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-space font-bold text-sm text-white">Department Allocation</h4>
                      <span className="text-[11px] font-mono text-slate-400">{department_breakdown.length} Sectors</span>
                    </div>
                    <div className="space-y-3">
                      {department_breakdown.map((dept) => {
                        const pct = summary.total_tools > 0 ? Math.round((dept.count / summary.total_tools) * 100) : 0;
                        return (
                          <div key={dept.department} className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className="text-slate-300">{dept.department}</span>
                              <span className="font-mono text-slate-400">{dept.count} tools ({pct}%)</span>
                            </div>
                            <div className="w-full bg-[#1e2226] border border-[#31363a] h-2 rounded-full overflow-hidden">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${pct}%` }}
                                transition={{ duration: 0.8 }}
                                className="bg-blue-600 h-full rounded-full"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Status Breakdown */}
                  <div className="p-5 rounded-lg bg-[#181b1e] border border-[#31363a] space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-space font-bold text-sm text-white">Lifecycle Status Summary</h4>
                      <span className="text-[11px] font-mono text-slate-400">{summary.total_tools} tools</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2.5">
                      {status_breakdown.map((s) => {
                        const style = getStatusStyle(s.current_status);
                        return (
                          <div key={s.current_status} className="p-3 rounded-md bg-[#1e2226] border border-[#31363a] flex items-center justify-between">
                            <span className={`text-xs font-semibold ${style.text}`}>
                              {s.current_status}
                            </span>
                            <span className="font-mono font-bold text-sm text-white">{s.count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 2: DEFECT DISPATCH REGISTER */}
            {activeTab === 'defects' && (
              <motion.div
                key="defects"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-space font-bold text-base text-white">
                    Defect Dispatch Register • Active Attention Required ({filteredDefects.length})
                  </h3>
                  <span className="text-xs font-mono text-rose-400 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30">
                    LOCKED: UNAVAILABLE
                  </span>
                </div>

                {filteredDefects.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400 font-mono bg-[#181b1e] rounded-lg border border-[#31363a]">
                    No flagged maintenance or defect notifications in current view.
                  </div>
                ) : (
                  <div className="divide-y divide-[#31363a] rounded-lg border border-[#31363a] overflow-hidden bg-[#181b1e]">
                    {filteredDefects.map((item) => (
                      <div
                        key={item.id}
                        className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-[#1e2226]/60 transition"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2.5 flex-wrap">
                            <span className="font-mono font-bold text-rose-400 text-xs bg-rose-500/15 px-2.5 py-0.5 rounded-full border border-rose-500/30">
                              # {item.id}
                            </span>
                            <span className="font-bold text-base text-white">{item.name}</span>
                            <span className="bg-rose-500/15 text-rose-400 border border-rose-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full font-mono">
                              DEFECT FLAGGED
                            </span>
                          </div>

                          <p className="text-xs text-slate-300">
                            <strong className="text-rose-400 font-semibold">Reported Issue:</strong> {item.defect_description || 'Abnormal wear or tolerance breach reported upon check-in.'}
                          </p>

                          <p className="text-[11px] text-slate-400 font-mono">
                            Reported by <strong className="text-white">{item.reported_by}</strong> on {new Date(item.reported_at).toLocaleString()} • Needs maintenanced at: <strong className="text-white">{item.current_location}</strong>
                          </p>
                        </div>

                        <div className="flex items-center space-x-4 text-right shrink-0">
                          <div className="text-xs">
                            <span className="text-slate-400 block text-[10px] font-semibold">Responsible Custodian</span>
                            <span className="font-bold text-white">{item.owner}</span>
                            <span className="text-[11px] text-slate-400 block font-mono">{item.department}</span>
                          </div>

                          <button
                            onClick={() => onSelectTool && onSelectTool(item.id)}
                            className="px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-1.5"
                          >
                            <span>Audit Asset</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* TAB 3: OVERDUE REGISTER */}
            {activeTab === 'overdue' && (
              <motion.div
                key="overdue"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-space font-bold text-base text-white">
                    Full Overdue Equipment Register ({filteredOverdue.length})
                  </h3>
                  <span className="text-xs font-mono text-slate-400">Shop supervisor clearance required</span>
                </div>

                {filteredOverdue.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400 font-mono bg-[#181b1e] rounded-lg border border-[#31363a]">
                    Zero overdue checkouts recorded in plant register.
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-lg border border-[#31363a] bg-[#181b1e]">
                    <table className="min-w-full divide-y divide-[#31363a] text-left text-xs">
                      <thead className="bg-[#1e2226] text-slate-300 font-semibold text-[11px] border-b border-[#31363a]">
                        <tr>
                          <th className="py-3 px-4">Tool ID</th>
                          <th className="py-3 px-4">Equipment Name</th>
                          <th className="py-3 px-4">Department</th>
                          <th className="py-3 px-4">Current Custodian</th>
                          <th className="py-3 px-4">Expected Return</th>
                          <th className="py-3 px-4">Days Overdue</th>
                          <th className="py-3 px-4 text-right">Audit</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#31363a] text-slate-200">
                        {filteredOverdue.map((item) => (
                          <tr key={item.id} className="hover:bg-[#1e2226]/60 transition">
                            <td className="py-3 px-4 font-mono font-bold text-blue-400"># {item.id}</td>
                            <td className="py-3 px-4 font-semibold text-white">{item.name}</td>
                            <td className="py-3 px-4 text-slate-300">{item.department}</td>
                            <td className="py-3 px-4 font-medium text-slate-200">{item.owner}</td>
                            <td className="py-3 px-4 font-mono text-slate-400">{item.expected_return_date}</td>
                            <td className="py-3 px-4">
                              <span className="bg-rose-500/15 text-rose-400 border border-rose-500/30 font-bold px-2.5 py-0.5 rounded-full text-[11px] font-mono">
                                {item.days_overdue} Day{item.days_overdue === 1 ? '' : 's'} Overdue
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button
                                onClick={() => onSelectTool && onSelectTool(item.id)}
                                className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-3 py-1 rounded-full transition"
                              >
                                View Tool
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </motion.div>
            )}

            {/* TAB 4: HIGH-WEAR FREQUENCY LEADERBOARD */}
            {activeTab === 'frequency' && (
              <motion.div
                key="frequency"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-space font-bold text-base text-white">
                    Maintenance Frequency Leaderboard ({filteredFrequency.length})
                  </h3>
                  <span className="text-xs font-mono text-amber-400">High-wear cycle assets</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredFrequency.map((item, index) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-lg bg-[#181b1e] border border-[#31363a] hover:border-blue-500/40 transition flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30 flex items-center justify-center font-mono text-xs font-bold">
                          #{index + 1}
                        </span>
                        <div>
                          <div className="font-bold text-white text-sm">{item.name}</div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                            # {item.id} • {item.department} • {item.type}
                          </div>
                        </div>
                      </div>

                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30 font-mono shrink-0">
                        {item.maintenance_events_count} Event{item.maintenance_events_count === 1 ? '' : 's'}
                      </span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* TAB 5: DORMANT ASSETS (> 30 DAYS IDLE) */}
            {activeTab === 'dormant' && (
              <motion.div
                key="dormant"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-space font-bold text-base text-white">
                    Inactive & Dormant Equipment ({filteredInactive.length})
                  </h3>
                  <span className="text-xs font-mono text-slate-400">Idle for over 30 days</span>
                </div>

                {filteredInactive.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400 font-mono bg-[#181b1e] rounded-lg border border-[#31363a]">
                    All workshop equipment recorded checkout or calibration activity within the last 30 days.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredInactive.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 rounded-lg bg-[#181b1e] border border-[#31363a] hover:border-blue-500/40 transition flex flex-col justify-between space-y-3"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono font-bold text-xs text-blue-400"># {item.id}</span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-[#1e2226] text-slate-300 border border-[#31363a]">
                              {item.days_inactive}d idle
                            </span>
                          </div>
                          <div className="font-bold text-white text-sm">{item.name}</div>
                          <div className="text-[11px] text-slate-400 mt-0.5">{item.current_location} • {item.current_status}</div>
                        </div>

                        <button
                          onClick={() => onSelectTool && onSelectTool(item.id)}
                          className="w-full py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition"
                        >
                          Audit Equipment
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* TAB 6: DEPARTMENT AUDIT */}
            {activeTab === 'departments' && (
              <motion.div
                key="departments"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-space font-bold text-base text-white">
                    Department Distribution & Custody Audit
                  </h3>
                  <span className="text-xs font-mono text-slate-400">{department_breakdown.length} Plant Sectors</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {department_breakdown.map((dept) => {
                    const pct = summary.total_tools > 0 ? Math.round((dept.count / summary.total_tools) * 100) : 0;
                    return (
                      <div key={dept.department} className="p-5 rounded-lg bg-[#181b1e] border border-[#31363a] space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-white text-base">{dept.department}</h4>
                          <span className="font-mono text-xs text-blue-400 font-bold">{dept.count} Assets ({pct}%)</span>
                        </div>
                        <div className="w-full bg-[#1e2226] border border-[#31363a] h-3 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${pct}%` }}
                            transition={{ duration: 0.8 }}
                            className="bg-blue-600 h-full rounded-full"
                          />
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono">
                          Equipment allocated across production and calibration lines.
                        </p>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Global Toast */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 bg-blue-600 text-white font-semibold px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2 text-xs border border-blue-400">
            <CheckCircle2 className="w-4 h-4 text-white" />
            <span>{toastMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
}
