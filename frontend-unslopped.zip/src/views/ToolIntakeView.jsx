import React, { useState, useEffect, useRef } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { api } from '../api';
import {
  QrCode,
  PlusCircle,
  Camera,
  Upload,
  Search,
  CheckCircle2,
  AlertCircle,
  X,
  ArrowRight,
  Wrench,
  ShieldCheck,
  Tag
} from 'lucide-react';

export default function ToolIntakeView({
  initialTab = 'scan',
  user,
  onToolDetected,
  onToolRegistered,
  onCancel
}) {
  const [activeTab, setActiveTab] = useState(initialTab); // 'scan' | 'register'

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // ==========================================
  // SCANNER STATE
  // ==========================================
  const [scannerActive, setScannerActive] = useState(false);
  const [manualId, setManualId] = useState('');
  const [scanError, setScanError] = useState(null);
  const [scanInfo, setScanInfo] = useState('');
  const html5QrCodeRef = useRef(null);

  // ==========================================
  // REGISTRATION STATE
  // ==========================================
  const [formData, setFormData] = useState({
    name: '',
    type: 'Power Tool',
    serial_number: '',
    department: user?.department || 'Assembly',
    location: 'Tool Crib A - Shelf 1',
    owner: user?.full_name || '',
    condition: 'New',
    maintenance_due_date: '',
    expected_return_date: '',
    notes: 'Initial tool registration into workshop database.'
  });
  const [registerLoading, setRegisterLoading] = useState(false);
  const [registerError, setRegisterError] = useState(null);

  const toolTypes = [
    'Power Tool',
    'Measuring Instrument',
    'Precision Hand Tool',
    'Heavy Machinery',
    'Pneumatic Tool',
    'Welding Equipment',
    'Electrical Testing',
    'General Workshop Tool'
  ];

  const departments = [
    'Assembly',
    'Quality Assurance',
    'Maintenance',
    'Fabrication',
    'Machining',
    'Carpentry & Crating',
    'Shop Management'
  ];

  const conditions = ['New', 'Good', 'Fair'];

  // ==========================================
  // SCANNER LOGIC
  // ==========================================
  const parseToolId = (decodedText) => {
    const urlMatch = decodedText.match(/\/tools\/([A-Za-z0-9_-]+)/i);
    if (urlMatch && urlMatch[1]) {
      return urlMatch[1].toUpperCase();
    }
    const directMatch = decodedText.match(/TL-\d+/i);
    if (directMatch) {
      return directMatch[0].toUpperCase();
    }
    return decodedText.trim().toUpperCase();
  };

  const handleScanSuccess = (decodedText) => {
    const toolId = parseToolId(decodedText);
    stopScanner();
    onToolDetected(toolId);
  };

  const startCamera = async () => {
    setScanError(null);
    setScanInfo('Requesting camera permissions...');

    try {
      if (html5QrCodeRef.current) {
        await stopScanner();
      }

      const qrCode = new Html5Qrcode('qr-intake-container');
      html5QrCodeRef.current = qrCode;

      const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 }
      };

      await qrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          handleScanSuccess(decodedText);
        },
        () => {}
      );

      setScannerActive(true);
      setScanInfo('Align the tool QR code within the targeting box.');
    } catch (err) {
      console.error('Camera initialization error:', err);
      setScanError('Unable to access video camera. You can upload a QR image or enter the Tool ID manually.');
      setScannerActive(false);
      setScanInfo('');
    }
  };

  const stopScanner = async () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      } catch (err) {
        console.error('Error stopping QR scanner:', err);
      }
    }
    setScannerActive(false);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setScanError(null);
    setScanInfo('Processing QR code image...');

    try {
      const qrCode = new Html5Qrcode('qr-intake-container');
      const result = await qrCode.scanFile(file, true);
      handleScanSuccess(result);
    } catch (err) {
      console.error('Image scan error:', err);
      setScanError('No legible QR code found in the selected image. Please try another image or key in the ID.');
      setScanInfo('');
    }
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (!manualId.trim()) return;
    onToolDetected(manualId.trim().toUpperCase());
  };

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [activeTab]);

  useEffect(() => {
    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch(() => {});
      }
    };
  }, []);

  // When switching tabs away from scan, stop the camera
  const handleSwitchTab = (tab) => {
    if (tab !== 'scan' && scannerActive) {
      stopScanner();
    }
    setActiveTab(tab);
  };

  // ==========================================
  // REGISTRATION LOGIC
  // ==========================================
  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.serial_number.trim()) {
      setRegisterError('Tool Name and Serial / Batch Number are required.');
      return;
    }

    setRegisterLoading(true);
    setRegisterError(null);

    try {
      const res = await api.registerTool(formData);
      onToolRegistered(res.tool.id);
    } catch (err) {
      setRegisterError(err.message || 'Failed to register tool.');
    } finally {
      setRegisterLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      
      {/* Top Breadcrumb & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-blue-400 mb-1">
            <span>TOOLTRACK FLEET</span>
            <span>•</span>
            <span className="">ASSET INTAKE & VERIFICATION</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-space text-white tracking-tight">
            Tool Intake & Scanner
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Scan physical equipment barcodes for live status or register new workshop assets with auto-generated QR identifiers.
          </p>
        </div>

        <button
          onClick={() => {
            stopScanner();
            onCancel();
          }}
          className="self-start sm:self-center text-xs bg-[#1e2226] hover:bg-[#272c30] text-slate-300 px-4 py-2 rounded-full border border-[#31363a] transition font-medium"
        >
          Back to Dashboard
        </button>
      </div>

      {/* Unified Tab Switcher Pill */}
      <div className="flex items-center justify-center mb-8">
        <div className="inline-flex rounded-full bg-[#1e2226] border border-[#31363a] p-1.5">
          <button
            onClick={() => handleSwitchTab('scan')}
            className={`flex items-center gap-2 px-5 py-2 text-xs font-semibold rounded-full transition-all duration-300 ${
              activeTab === 'scan'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Scan QR / Barcode</span>
          </button>

          <button
            onClick={() => handleSwitchTab('register')}
            className={`flex items-center gap-2 px-5 py-2 text-xs font-semibold rounded-full transition-all duration-300 ${
              activeTab === 'register'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Register New Asset</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: SCAN QR CODE                                                      */}
      {/* ========================================================================= */}
      {activeTab === 'scan' && (
        <div className="bg-[#181b1e] border border-[#31363a] rounded-lg shadow-2xl overflow-hidden text-white animate-in fade-in duration-300">
          <div className="bg-[#1e2226] border-b border-[#31363a] px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-md bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <QrCode className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-bold font-space text-white">Live Scanner Viewport</h2>
                <span className="text-[11px] text-slate-400 font-mono">Compatible with 2D QR and Code-128 workshop barcodes</span>
              </div>
            </div>
            {scannerActive && (
              <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                Live Camera
              </span>
            )}
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            {scanError && (
              <div className="bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs px-4 py-3 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{scanError}</span>
              </div>
            )}

            {scanInfo && !scanError && (
              <div className="bg-blue-950/40 border border-blue-500/40 text-blue-300 text-xs px-4 py-3 rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{scanInfo}</span>
              </div>
            )}

            {/* Scanner Viewport Box */}
            <div className="border border-[#31363a] rounded-lg bg-[#121416] p-6 min-h-[300px] flex flex-col items-center justify-center relative">
              <div id="qr-intake-container" className="w-full max-w-[340px] rounded-md overflow-hidden"></div>

              {!scannerActive && (
                <div className="text-center py-6">
                  <div className="w-14 h-14 bg-blue-500/15 border border-blue-500/30 text-blue-400 rounded-lg mx-auto flex items-center justify-center mb-3">
                    <Camera className="w-7 h-7" />
                  </div>
                  <p className="text-base font-bold text-white font-space">Optical Scanner Offline</p>
                  <p className="text-xs text-slate-400 mt-1 mb-6 max-w-sm mx-auto">
                    Activate camera to scan asset QR code from tooling badges, metal tags, or calibration labels.
                  </p>
                  <button
                    type="button"
                    onClick={startCamera}
                    className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-6 py-2.5 rounded-full transition flex items-center gap-2 mx-auto"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Activate Live Camera</span>
                  </button>
                </div>
              )}

              {scannerActive && (
                <div className="mt-4">
                  <button
                    type="button"
                    onClick={stopScanner}
                    className="bg-[#1e2226] hover:bg-[#272c30] text-slate-200 text-xs font-semibold px-4 py-2 rounded-full border border-[#31363a] transition"
                  >
                    Stop Camera Stream
                  </button>
                </div>
              )}
            </div>

            {/* Alternative Methods: Image Upload & Manual Key-in */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="border border-[#31363a] rounded-lg p-5 bg-[#1e2226]">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 mb-1.5">
                  <Upload className="w-3.5 h-3.5 text-blue-400" />
                  <span>Upload QR Image File</span>
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  Upload a photo or captured screenshot of a tool barcode
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="block w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-white/[0.08] file:text-white hover:file:bg-white/[0.14] cursor-pointer"
                />
              </div>

              <div className="border border-[#31363a] rounded-lg p-5 bg-[#1e2226]">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 mb-1.5">
                  <Search className="w-3.5 h-3.5 text-blue-400" />
                  <span>Direct Tool ID Lookup</span>
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  Key in tool identifier directly (e.g. TL-1001)
                </p>
                <form onSubmit={handleManualSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={manualId}
                    onChange={(e) => setManualId(e.target.value)}
                    placeholder="TL-1001"
                    className="flex-1 px-4 py-2 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2 rounded-md transition"
                  >
                    Search
                  </button>
                </form>
              </div>
            </div>

            {/* Fast Demo Tools Jump */}
            <div className="bg-[#1e2226] rounded-lg p-5 border border-[#31363a]">
              <span className="text-xs font-semibold text-slate-400 block mb-3 font-mono">
                Workshop Test Fleet • Click to simulate instant QR scan:
              </span>
              <div className="flex flex-wrap gap-2">
                {['TL-1001', 'TL-1002', 'TL-1003', 'TL-1004', 'TL-1005', 'TL-1006', 'TL-1007', 'TL-1008', 'TL-1009', 'TL-1010'].map(id => (
                  <button
                    key={id}
                    onClick={() => onToolDetected(id)}
                    className="bg-[#121416] hover:bg-blue-600 hover:text-white text-slate-300 text-xs font-mono font-semibold px-3 py-1.5 rounded-full border border-[#31363a] transition"
                  >
                    {id}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: REGISTER NEW TOOL                                                 */}
      {/* ========================================================================= */}
      {activeTab === 'register' && (
        <div className="bg-[#181b1e] border border-[#31363a] rounded-lg shadow-2xl overflow-hidden text-white animate-in fade-in duration-300">
          <div className="bg-[#1e2226] border-b border-[#31363a] px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-md bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <PlusCircle className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-bold font-space text-white">Register Workshop Equipment</h2>
                <span className="text-[11px] text-slate-400 font-mono">Generates ISO-9001 compliance record & QR code tag</span>
              </div>
            </div>
            <span className="text-xs text-blue-400 bg-blue-500/15 px-3 py-1 rounded-full border border-blue-500/30 font-mono">
              Auto-ID Enabled
            </span>
          </div>

          {registerError && (
            <div className="mx-6 mt-6 bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs px-4 py-3 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{registerError}</span>
            </div>
          )}

          <form onSubmit={handleFormSubmit} className="p-6 sm:p-8 space-y-5 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Tool Name */}
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Tool Name / Equipment Description *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  placeholder="e.g. Bosch 18V Cordless Impact Driver or Mitutoyo Digital Micrometer"
                  required
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {/* Tool Type */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Equipment Category *
                </label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                >
                  {toolTypes.map(t => (
                    <option key={t} value={t} className="bg-[#121416] text-white">{t}</option>
                  ))}
                </select>
              </div>

              {/* Serial Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Serial / Batch Number *
                </label>
                <input
                  type="text"
                  name="serial_number"
                  value={formData.serial_number}
                  onChange={handleFormChange}
                  placeholder="e.g. SN-BOS-98214"
                  required
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {/* Department */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Assigned Department *
                </label>
                <select
                  name="department"
                  value={formData.department}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                >
                  {departments.map(d => (
                    <option key={d} value={d} className="bg-[#121416] text-white">{d}</option>
                  ))}
                </select>
              </div>

              {/* Home / Intake Location */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Storage Rack / Bay Station *
                </label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleFormChange}
                  placeholder="e.g. Tool Crib A - Shelf 2 or Bay 1"
                  required
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {/* Tool Custodian / Owner */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Designated Custodian / Owner
                </label>
                <input
                  type="text"
                  name="owner"
                  value={formData.owner}
                  onChange={handleFormChange}
                  placeholder="e.g. Marcus Vance"
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {/* Condition */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Intake Condition
                </label>
                <select
                  name="condition"
                  value={formData.condition}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                >
                  {conditions.map(c => (
                    <option key={c} value={c} className="bg-[#121416] text-white">{c}</option>
                  ))}
                </select>
              </div>

              {/* Calibration Due Date */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Next Calibration / Inspection Date
                </label>
                <input
                  type="date"
                  name="maintenance_due_date"
                  value={formData.maintenance_due_date}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">Optional: for periodic calibration tracking</span>
              </div>

              {/* Expected Return Date */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Expected Return Date
                </label>
                <input
                  type="date"
                  name="expected_return_date"
                  value={formData.expected_return_date}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">Leave empty if kept in crib storage</span>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                Intake Notes & Inspection Comments
              </label>
              <textarea
                name="notes"
                rows={3}
                value={formData.notes}
                onChange={handleFormChange}
                placeholder="e.g. PO number, supplier invoice details, unboxing comments"
                className="w-full px-4 py-2.5 text-xs rounded-md bg-[#121416] border border-[#31363a] text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-[#31363a] flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => handleSwitchTab('scan')}
                className="px-4 py-2 rounded-full border border-[#31363a] text-xs font-medium text-slate-300 hover:text-white hover:bg-[#1e2226] transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={registerLoading}
                className="px-6 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition disabled:opacity-50 flex items-center gap-2"
              >
                {registerLoading ? (
                  <span>Registering Tool...</span>
                ) : (
                  <>
                    <span>Register Tool & Generate QR</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
