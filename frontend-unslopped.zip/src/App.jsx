import React, { useState, useEffect } from 'react';
import { api } from './api';
import Navbar from './components/Navbar';
import LoginView from './views/LoginView';
import DashboardView from './views/DashboardView';
import ToolIntakeView from './views/ToolIntakeView';
import ToolDetailView from './views/ToolDetailView';
import PrivacyPolicyView from './views/PrivacyPolicyView';
import TermsConditionsView from './views/TermsConditionsView';
import ReportsView from './views/ReportsView';

export default function App() {
  const [user, setUser] = useState(api.getUser());
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedToolId, setSelectedToolId] = useState(null);

  // Synchronize route based on URL path e.g. /tools/TL-1001 from QR scans
  const syncRouteFromUrl = () => {
    const path = window.location.pathname;
    const toolMatch = path.match(/\/tools\/([A-Za-z0-9_-]+)/i);
    if (toolMatch && toolMatch[1]) {
      setSelectedToolId(toolMatch[1].toUpperCase());
      setCurrentView('tool-detail');
      return;
    }

    if (path === '/privacy') {
      setCurrentView('privacy');
      return;
    }

    if (path === '/terms') {
      setCurrentView('terms');
      return;
    }

    if (path === '/reports') {
      setCurrentView('reports');
      return;
    }

    if (path === '/intake' || path === '/scan' || path === '/register') {
      setCurrentView('intake');
      return;
    }

  };

  useEffect(() => {
    syncRouteFromUrl();

    // Listen to browser back/forward buttons
    const handlePopState = () => syncRouteFromUrl();
    window.addEventListener('popstate', handlePopState);

    // Global session expiration handler
    const handleExpired = () => {
      setUser(null);
      setCurrentView('dashboard');
    };
    window.addEventListener('auth-expired', handleExpired);

    // Legal page custom navigation events from footer
    const handleNavPrivacy = () => {
      window.history.pushState({}, '', '/privacy');
      setCurrentView('privacy');
    };
    const handleNavTerms = () => {
      window.history.pushState({}, '', '/terms');
      setCurrentView('terms');
    };
    window.addEventListener('nav-privacy', handleNavPrivacy);
    window.addEventListener('nav-terms', handleNavTerms);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('auth-expired', handleExpired);
      window.removeEventListener('nav-privacy', handleNavPrivacy);
      window.removeEventListener('nav-terms', handleNavTerms);
    };
  }, []);

  const handleLoginSuccess = (authenticatedUser) => {
    setUser(authenticatedUser);
    syncRouteFromUrl();
  };

  const handleLogout = () => {
    api.clearAuth();
    setUser(null);
    setCurrentView('dashboard');
    window.history.pushState({}, '', '/');
  };

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [currentView, selectedToolId]);

  const navigateToView = (viewName) => {
    setCurrentView(viewName);
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (viewName === 'dashboard') {
      window.history.pushState({}, '', '/');
    } else if (viewName === 'intake' || viewName === 'register' || viewName === 'scan') {
      window.history.pushState({}, '', '/intake');
    } else if (viewName === 'reports') {
      window.history.pushState({}, '', '/reports');
    } else if (viewName === 'privacy') {
      window.history.pushState({}, '', '/privacy');
    } else if (viewName === 'terms') {
      window.history.pushState({}, '', '/terms');
    }
  };

  const handleSelectTool = (toolId) => {
    setSelectedToolId(toolId);
    setCurrentView('tool-detail');
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    window.history.pushState({}, '', `/tools/${toolId}`);
  };

  const handleToolRegistered = (newToolId) => {
    setSelectedToolId(newToolId);
    setCurrentView('tool-detail');
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    window.history.pushState({}, '', `/tools/${newToolId}`);
  };

  // If user is not authenticated, show login view
  if (!user) {
    if (currentView === 'privacy') {
      return <PrivacyPolicyView onBack={() => setCurrentView('dashboard')} />;
    }
    if (currentView === 'terms') {
      return <TermsConditionsView onBack={() => setCurrentView('dashboard')} />;
    }
    return <LoginView onLoginSuccess={handleLoginSuccess} user={user} onNavigate={navigateToView} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#121416] text-slate-100 selection:bg-blue-600/30 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        currentView={currentView}
        setView={navigateToView}
        user={user}
        onUpdateUser={(updated) => {
          setUser(updated);
          api.setAuth(api.getToken(), updated);
        }}
        onLogout={handleLogout}
      />

      {/* Main Body View Switching */}
      <main className="flex-1">
        {currentView === 'dashboard' && (
          <DashboardView
            user={user}
            onSelectTool={handleSelectTool}
            onRegisterNew={() => navigateToView('register')}
            onScanQR={() => navigateToView('scan')}
            onNavigateView={navigateToView}
          />
        )}

        {(currentView === 'intake' || currentView === 'scan' || currentView === 'register') && (
          <ToolIntakeView
            initialTab={currentView === 'register' ? 'register' : 'scan'}
            user={user}
            onToolDetected={(id) => handleSelectTool(id)}
            onToolRegistered={handleToolRegistered}
            onCancel={() => navigateToView('dashboard')}
          />
        )}

        {currentView === 'tool-detail' && selectedToolId && (
          <ToolDetailView
            toolId={selectedToolId}
            user={user}
            onBack={() => navigateToView('dashboard')}
          />
        )}

        {currentView === 'privacy' && (
          <PrivacyPolicyView onBack={() => navigateToView('dashboard')} />
        )}

        {currentView === 'terms' && (
          <TermsConditionsView onBack={() => navigateToView('dashboard')} />
        )}

        {currentView === 'reports' && (
          <ReportsView
            onSelectTool={handleSelectTool}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="bg-[#181b1e] border-t border-[#31363a] py-5 px-4 sm:px-6 mt-12 no-print text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
          <div>
            <span>ToolTrack</span>
          </div>

          <div className="flex items-center space-x-4">
            <button onClick={() => navigateToView('privacy')} className="hover:underline hover:text-blue-400">
              Privacy
            </button>
            
            <button onClick={() => navigateToView('terms')} className="hover:underline hover:text-blue-400">
              Terms
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
