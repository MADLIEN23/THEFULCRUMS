// Status color mappings and visual indicators for ToolTrack

// Status color mappings and visual indicators for ToolTrack

export const STATUS_CONFIG = {
  Registered: {
    label: 'Registered',
    bg: 'bg-slate-500/15',
    text: 'text-slate-300',
    border: 'border-slate-500/30',
    dot: 'bg-slate-400'
  },
  Received: {
    label: 'Received',
    bg: 'bg-sky-500/15',
    text: 'text-sky-300',
    border: 'border-sky-500/30',
    dot: 'bg-sky-400'
  },
  Inspected: {
    label: 'Inspected',
    bg: 'bg-blue-500/15',
    text: 'text-blue-300',
    border: 'border-blue-500/30',
    dot: 'bg-blue-400'
  },
  Issued: {
    label: 'Issued',
    bg: 'bg-indigo-500/15',
    text: 'text-indigo-300',
    border: 'border-indigo-500/30',
    dot: 'bg-indigo-400'
  },
  'In Use': {
    label: 'In Use',
    bg: 'bg-emerald-500/15',
    text: 'text-emerald-300',
    border: 'border-emerald-500/30',
    dot: 'bg-emerald-400'
  },
  Returned: {
    label: 'Returned',
    bg: 'bg-amber-500/15',
    text: 'text-amber-300',
    border: 'border-amber-500/30',
    dot: 'bg-amber-400'
  },
  'Sent for Maintenance': {
    label: 'Sent for Maintenance',
    bg: 'bg-orange-500/15',
    text: 'text-orange-300',
    border: 'border-orange-500/30',
    dot: 'bg-orange-400'
  },
  Repaired: {
    label: 'Repaired',
    bg: 'bg-teal-500/15',
    text: 'text-teal-300',
    border: 'border-teal-500/30',
    dot: 'bg-teal-400'
  },
  Retired: {
    label: 'Retired',
    bg: 'bg-zinc-500/15',
    text: 'text-zinc-400',
    border: 'border-zinc-500/30',
    dot: 'bg-zinc-500'
  }
};

export function getStatusStyle(status) {
  return STATUS_CONFIG[status] || {
    label: status || 'Unknown',
    bg: 'bg-slate-500/15',
    text: 'text-slate-300',
    border: 'border-slate-500/30',
    dot: 'bg-slate-400'
  };
}
