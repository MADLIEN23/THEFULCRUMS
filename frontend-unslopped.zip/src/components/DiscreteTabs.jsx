import React, { useState } from 'react';
import { motion } from 'motion/react';

export const DiscreteTabs = ({
  tabs = [],
  defaultTab,
  value,
  onChange,
  className = ''
}) => {
  const [internalTab, setInternalTab] = useState(defaultTab || (tabs[0] && tabs[0].id));
  const activeTab = value !== undefined ? value : internalTab;

  const handleSelect = (id) => {
    if (onChange) onChange(id);
    if (value === undefined) setInternalTab(id);
  };

  return (
    <div
      className={`inline-flex items-center gap-1.5 p-1.5 rounded-full bg-[#1e2226] border border-[#31363a] select-none ${className}`}
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => handleSelect(tab.id)}
            className={`relative flex items-center gap-2 px-3.5 py-2 rounded-full text-xs font-semibold transition-colors duration-200 outline-none ${
              isActive
                ? 'text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isActive && (
              <motion.div
                layoutId="discrete-active-pill"
                className="absolute inset-0 bg-blue-600 rounded-full border border-blue-400/30"
                transition={{ type: 'spring', stiffness: 380, damping: 28 }}
              />
            )}

            <span className="relative z-10 flex items-center justify-center shrink-0">
              {tab.icon}
            </span>

            {isActive && (
              <motion.span
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: 'auto' }}
                exit={{ opacity: 0, width: 0 }}
                transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                className="relative z-10 overflow-hidden whitespace-nowrap font-medium"
              >
                {tab.label}
              </motion.span>
            )}

            {tab.badge !== undefined && tab.badge !== null && (
              <span
                className={`relative z-10 ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isActive
                    ? 'bg-white/25 text-white'
                    : 'bg-white/10 text-zinc-400'
                }`}
              >
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default DiscreteTabs;
