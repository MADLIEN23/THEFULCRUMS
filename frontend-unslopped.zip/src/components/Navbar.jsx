import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ProfileModal from './ProfileModal';
import {
  Wrench,
  Activity,
  PlusCircle,
  QrCode,
  FileText,
  Plus,
  Folder,
  ClipboardList,
  Trophy,
  Flag,
  Calendar,
  X,
  User as UserIcon,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

export default function Navbar({ currentView, setView, user, onUpdateUser, onLogout }) {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(user);

  useEffect(() => {
    setCurrentUser(user);
  }, [user]);

  const getInitials = (name) => {
    if (!name || !name.trim()) return 'OP';
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  const roleBadgeColors = {
    Admin: 'bg-rose-500/15 text-rose-300 border border-rose-500/30',
    Inspector: 'bg-blue-500/15 text-blue-300 border border-blue-500/30',
    Operator: 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
  };

  return (
    <>
      <header className="bg-[#181b1e] text-white border-b border-[#31363a] sticky top-0 z-40 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Brand Logo & Title */}
            <div
              className="flex items-center space-x-3 cursor-pointer group"
              onClick={() => setView('dashboard')}
            >
              <div className="w-8 h-8 rounded-md bg-blue-500 flex items-center justify-center">
                <Wrench className="w-4 h-4 text-[#17140b]" />
              </div>
              <div>
                <span className="font-space font-semibold text-xl text-white">ToolTrack</span>
              </div>
            </div>

            {/* Animated Floating Dark Pill Segmented Control */}
            <div className="hidden md:flex items-center gap-1 relative">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: Activity, iconColor: 'text-blue-300' },
                { id: 'intake', label: 'Scan or register', icon: QrCode, iconColor: 'text-slate-300', match: ['intake', 'scan', 'register'] },
                { id: 'reports', label: 'Reports', icon: FileText, iconColor: 'text-slate-300' },
              ].map((tab) => {
                const isActive = tab.match ? tab.match.includes(currentView) : currentView === tab.id;
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setView(tab.id)}
                    className={`relative z-10 flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-md transition-colors duration-200 select-none ${
                      isActive
                        ? 'text-white'
                        : tab.special
                        ? 'text-cyan-400 hover:text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="navbarActiveIndicator"
                        className="absolute inset-0 rounded-md bg-[#272c30]"
                        transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                      />
                    )}
                    <motion.span
                      className="relative z-10 flex items-center justify-center"
                                            transition={{ type: 'spring', stiffness: 400, damping: 17 }}
                    >
                      <Icon className={`w-3.5 h-3.5 ${tab.iconColor}`} />
                    </motion.span>
                    <span className="relative z-10">{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Right Side: Create New + Profile + Sign out */}
            <div className="flex items-center space-x-3">
              {/* Reference Image 4: "Create New" Action Modal Trigger */}
              <button
                onClick={() => setShowCreateModal(true)}
                className="hidden lg:flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-full bg-blue-600 hover:bg-blue-500 text-white transition-all"
              >
                <Plus className="w-3.5 h-3.5 text-white" />
                <span>New</span>
              </button>

              {/* Reference Image 3: Clickable Profile Trigger */}
              <div
                onClick={() => setShowProfileModal(true)}
                className="flex items-center space-x-2.5 cursor-pointer p-1 rounded-full hover:bg-white/[0.05] transition group"
                title="Edit your profile"
              >
                <div className="w-8 h-8 rounded-full border border-[#3a4045]">
                  <div className="w-full h-full rounded-full bg-[#1e2226] flex items-center justify-center font-semibold text-xs text-white overflow-hidden">
                    {currentUser?.avatar ? (
                      <img src={currentUser.avatar} alt="avatar" className="w-full h-full object-cover" />
                    ) : (
                      getInitials(currentUser?.full_name)
                    )}
                  </div>
                </div>

                {currentUser && (
                  <div className="hidden xl:flex flex-col text-left">
                    <span className="text-xs font-semibold text-white leading-tight">
                      {currentUser.full_name}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {currentUser.department}
                    </span>
                  </div>
                )}
              </div>

              {currentUser && (
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${roleBadgeColors[currentUser.role] || 'bg-blue-600/20 text-blue-300 border border-blue-500/30'}`}>
                  {currentUser.role}
                </span>
              )}

              <button
                onClick={onLogout}
                className="text-xs bg-[#1e2226] hover:bg-blue-600 hover:text-white text-slate-300 px-3 py-1.5 rounded-full border border-[#31363a] font-medium transition"
              >
                Sign out
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Reference Image 3: "Edit your profile" Modal */}
      <ProfileModal
        user={currentUser}
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onSave={(updated) => {
          setCurrentUser(updated);
          if (onUpdateUser) onUpdateUser(updated);
        }}
      />

      {/* Reference Image 4: "Create New" Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm rounded-lg bg-[#181b1e] border border-[#31363a] p-6 shadow-2xl text-white">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-space font-bold text-lg text-white">New</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="w-7 h-7 rounded-full bg-white/[0.08] hover:bg-white/[0.16] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'register', label: 'Register Asset', icon: PlusCircle, view: 'register' },
                { id: 'scan', label: 'Scan Tool QR', icon: QrCode, view: 'scan' },
                { id: 'maintenance', label: 'Log maintenance', icon: AlertTriangle, view: 'dashboard' },
                { id: 'calibration', label: 'Calibration', icon: Calendar, view: 'dashboard' },
                { id: 'qa', label: 'QA sign-off', icon: CheckCircle2, view: 'dashboard' },
                { id: 'reports', label: 'Audit report', icon: FileText, view: 'reports' },
              ].map(({ id, label, icon: Icon, view }) => (
                <button
                  key={id}
                  onClick={() => {
                    setShowCreateModal(false);
                    if (id === 'maintenance') {
                      setView('dashboard');
                      setTimeout(() => window.dispatchEvent(new CustomEvent('open-maint-dialog')), 100);
                    } else if (id === 'calibration') {
                      setView('dashboard');
                      setTimeout(() => window.dispatchEvent(new CustomEvent('open-calib-dialog')), 100);
                    } else if (id === 'qa') {
                      setView('dashboard');
                      setTimeout(() => window.dispatchEvent(new CustomEvent('open-qa-dialog')), 100);
                    } else {
                      setView(view);
                    }
                  }}
                  className="flex flex-col items-center justify-center py-5 px-3 rounded-lg bg-[#1e2226] hover:bg-blue-600/15 border border-[#31363a] hover:border-blue-500 transition-all duration-200 group"
                >
                  <Icon className="w-6 h-6 text-slate-300 group-hover:text-blue-400 group-hover:scale-110 transition-all mb-2.5" />
                  <span className="text-xs font-medium text-slate-300 group-hover:text-white text-center">{label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
