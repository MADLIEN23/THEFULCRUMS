import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MoreHorizontal, Copy, Check, ArrowUpRight, Cpu, Box, Gauge, Wrench, ShieldCheck } from 'lucide-react';

const DEFAULT_CARDS = [
  {
    id: 'bay-a',
    title: 'CNC Machining Bay A',
    value: '14 Active Spindles',
    subtitle: 'High-Precision Milling Cell',
    color: 'bg-black border border-red-600/40',
    icon: Box,
    badge: 'Nominal Runout',
    details: {
      utilization: '94.2%',
      temperature: '42°C',
      health: '100% OK',
      technician: 'Marcus Vance'
    }
  },
  {
    id: 'crib-alpha',
    title: 'Central Tool Crib',
    value: '48 Tools Ready',
    subtitle: 'Automated NFC Inventory Vault',
    color: 'bg-black border border-[#31363a]',
    icon: Box,
    badge: 'NFC Live',
    details: {
      utilization: '68.0%',
      temperature: '21°C',
      health: 'Audited',
      technician: 'Elena Rostova'
    }
  },
  {
    id: 'qc-bench',
    title: 'QC Metrology Bench',
    value: '6 In Calibration',
    subtitle: 'ISO-9001 Micro-Tolerancing',
    color: 'bg-black border border-red-600/40',
    icon: Gauge,
    badge: 'ISO Certified',
    details: {
      utilization: '88.5%',
      temperature: '20°C (Controlled)',
      health: 'Calibration Due: 4d',
      technician: 'Sarah Chen'
    }
  },
  {
    id: 'assembly-2',
    title: 'Assembly & Fab Line 2',
    value: '22 In Custody',
    subtitle: 'Robotic Torque & Fastening Cell',
    color: 'bg-black border border-[#31363a]',
    icon: Wrench,
    badge: 'Active Shift',
    details: {
      utilization: '91.8%',
      temperature: '38°C',
      health: 'Zero Flags',
      technician: 'Alex Rivera'
    }
  }
];

export const MinimalCarousel = ({
  cards = DEFAULT_CARDS,
  onSelectStation
}) => {
  const [activeId, setActiveId] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  const activeCard = cards.find((c) => c.id === activeId);
  const secondaryCards = cards.filter((c) => c.id !== activeId);

  const handleBackgroundClick = (e) => {
    if (e.target === e.currentTarget) setActiveId(null);
  };

  const handleCopy = (card) => {
    navigator.clipboard.writeText(`${card.title}: ${card.value} (ID: ${card.id})`);
    setCopiedId(card.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full flex items-center justify-center bg-transparent py-4">
      <div
        className="w-full flex flex-col items-center justify-center select-none font-sans"
        onClick={handleBackgroundClick}
      >
        {/* Header Ribbon */}
        <div className="w-full max-w-lg mb-4 flex items-center justify-between text-xs px-1">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-lime-400 animate-pulse" />
            <span className="font-space font-semibold text-white text-[11px]">
              Workshop Stations & Tool Pods
            </span>
          </div>
          <span className="text-slate-400 text-[11px]">
            {activeId ? 'Click background to collapse' : 'Click card to expand telemetry'}
          </span>
        </div>

        {/* Container */}
        <div className="w-full max-w-lg">
          <motion.div layout className="flex flex-col gap-3">
            
            {/* Expanded Card */}
            <AnimatePresence mode="popLayout">
              {activeCard && (
                <motion.div
                  key={activeCard.id}
                  layoutId={activeCard.id}
                  className={`relative flex w-full flex-col justify-between
                             rounded-lg  p-5 sm:p-6 text-white shadow-2xl
                             ${activeCard.color}
                             min-h-52 sm:min-h-56`}
                  transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white/20 shrink-0">
                        <activeCard.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/20">
                          {activeCard.badge || 'Nominal'}
                        </span>
                        <div className="text-xs text-white/80 mt-1">{activeCard.subtitle}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <motion.button
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopy(activeCard);
                        }}
                        className="flex items-center gap-1.5 rounded-full bg-white/15 hover:bg-white/25
                                   px-3.5 py-1.5 font-bold text-xs whitespace-nowrap transition-colors"
                      >
                        {copiedId === activeCard.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-lime-300" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Station ID</span>
                          </>
                        )}
                      </motion.button>
                      <button
                        onClick={() => setActiveId(null)}
                        className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-xs"
                      >
                        ✕
                      </button>
                    </div>
                  </div>

                  {/* Telemetry Stats in Expanded Card */}
                  {activeCard.details && (
                    <div className="grid grid-cols-4 gap-2 my-3 p-3 rounded-lg bg-black/20 border border-white/10 text-center">
                      <div>
                        <div className="text-[10px] text-white/60">Utilization</div>
                        <div className="font-space font-bold text-xs sm:text-sm">{activeCard.details.utilization}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-white/60">Temp</div>
                        <div className="font-space font-bold text-xs sm:text-sm">{activeCard.details.temperature}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-white/60">Health</div>
                        <div className="font-space font-bold text-xs sm:text-sm text-lime-300">{activeCard.details.health}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-white/60">Technician</div>
                        <div className="font-space font-bold text-xs sm:text-sm truncate">{activeCard.details.technician}</div>
                      </div>
                    </div>
                  )}

                  <div className="flex items-end justify-between mt-2">
                    <div className="overflow-hidden mr-2">
                      <h3 className="text-xl sm:text-2xl font-bold font-space leading-tight truncate">
                        {activeCard.title}
                      </h3>
                      <p className="text-sm sm:text-base font-medium opacity-85 truncate">
                        {activeCard.value}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onSelectStation) onSelectStation(activeCard);
                      }}
                      className="rounded-full bg-white/25 hover:bg-white/35 px-4 py-2
                                 text-xs sm:text-sm font-bold transition-colors shrink-0 flex items-center gap-1.5"
                    >
                      <span>Filter Equipment</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Grid Layout (2 columns or 3 columns when active card expanded) */}
            <motion.div
              layout
              className={`grid gap-3 transition-all duration-500 ${
                activeId ? 'grid-cols-3' : 'grid-cols-2'
              }`}
            >
              {(activeId ? secondaryCards : cards).map((card) => {
                const CardIcon = card.icon;
                return (
                  <motion.div
                    key={card.id}
                    layoutId={card.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveId(card.id);
                    }}
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    className={`relative flex flex-col justify-between cursor-pointer
                               rounded-lg  p-4 text-white
                               ${card.color}
                               hover:scale-[1.02] active:scale-[0.98] transition-all
                               ${activeId ? 'h-28 sm:h-32' : 'h-32 sm:h-36'}`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="w-8 h-8 rounded-md bg-white/20 flex items-center justify-center shrink-0">
                        <CardIcon size={activeId ? 18 : 20} />
                      </div>
                      <div className="rounded-full bg-white/10 hover:bg-white/20 p-1 transition-colors">
                        <MoreHorizontal size={15} />
                      </div>
                    </div>

                    <div className="mt-2 overflow-hidden">
                      <h4
                        className={`${
                          activeId ? 'text-xs' : 'text-sm sm:text-base'
                        } font-bold font-space opacity-95 truncate leading-tight`}
                      >
                        {card.title}
                      </h4>
                      <p
                        className={`${
                          activeId ? 'text-[11px]' : 'text-xs sm:text-sm'
                        } font-medium text-white/70 truncate mt-0.5`}
                      >
                        {card.value}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default MinimalCarousel;
