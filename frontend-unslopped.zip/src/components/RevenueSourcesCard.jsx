import React, { useState } from 'react';

export const RevenueSourcesCard = ({
  title = 'Revenue Sources',
  className = ''
}) => {
  const [mode, setMode] = useState('financial');
  const [hoveredIndex, setHoveredIndex] = useState(null);

  const financialItems = [
    {
      id: 'subscriptions',
      label: 'Subscriptions',
      count: 12450,
      color: 'bg-red-500',
      strokeColor: '#ef4444',
      subLabel: 'Enterprise Fleet Leases'
    },
    {
      id: 'onetime',
      label: 'One-time Sales',
      count: 8320,
      color: 'bg-red-600',
      strokeColor: '#dc2626',
      subLabel: 'Capital Spares & Machinery'
    },
    {
      id: 'services',
      label: 'Services',
      count: 4110,
      color: 'bg-red-800',
      strokeColor: '#991b1b',
      subLabel: 'Metrology & ISO Calibrations'
    }
  ];

  const fleetItems = [
    {
      id: 'in_use',
      label: 'Active in Bays',
      count: 12450,
      color: 'bg-red-500',
      strokeColor: '#ef4444',
      subLabel: 'Machining & Assembly'
    },
    {
      id: 'available',
      label: 'Tool Crib Ready',
      count: 8320,
      color: 'bg-red-600',
      strokeColor: '#dc2626',
      subLabel: 'Checked in & Inspected'
    },
    {
      id: 'maintenance',
      label: 'Servicing & QA',
      count: 4110,
      color: 'bg-red-800',
      strokeColor: '#991b1b',
      subLabel: 'Calibration & Repair'
    }
  ];

  const currentItems = mode === 'financial' ? financialItems : fleetItems;
  const total = currentItems.reduce((acc, curr) => acc + curr.count, 0);

  // SVG circular calculations
  const radius = 38;
  const circumference = 2 * Math.PI * radius; // ~238.76

  // Compute strokeDasharray and strokeDashoffset for 3 segments
  let accumulatedPercent = 0;
  const segments = currentItems.map((item, idx) => {
    const percent = item.count / total;
    const strokeDasharray = `${percent * circumference} ${circumference}`;
    const strokeDashoffset = -accumulatedPercent * circumference;
    accumulatedPercent += percent;
    return {
      ...item,
      strokeDasharray,
      strokeDashoffset,
      percent: Math.round(percent * 100)
    };
  });

  const formatNumber = (num) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  return (
    <div
      className={`rounded-lg bg-[#121416] border border-[#31363a] p-6 sm:p-7 shadow-2xl transition-all duration-300 hover:border-red-600/40 ${className}`}
    >
      {/* Header with Title and Mode Switcher */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-space font-bold text-lg sm:text-xl text-white tracking-tight">
          {mode === 'financial' ? title : 'Equipment Allocation'}
        </h3>
        
        {/* Subtle pill toggle */}
        <button
          onClick={() => setMode(mode === 'financial' ? 'fleet' : 'financial')}
          className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-white/[0.06] hover:bg-white/[0.12] text-slate-300 border border-white/[0.08] transition"
        >
          {mode === 'financial' ? 'View Fleet' : 'View Revenue'}
        </button>
      </div>

      {/* Main Content: Donut on Left, Legend on Right */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 sm:gap-8">
        
        {/* Donut Chart SVG */}
        <div className="relative w-36 h-36 flex items-center justify-center shrink-0">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            {/* Background ring */}
            <circle
              cx="50"
              cy="50"
              r={radius}
              stroke="#111111"
              strokeWidth="11"
              fill="none"
            />

            {/* Segmented Arcs with 3-shade green */}
            {segments.map((seg, i) => (
              <circle
                key={seg.id}
                cx="50"
                cy="50"
                r={radius}
                stroke={seg.strokeColor}
                strokeWidth={hoveredIndex === i ? 13 : 11}
                strokeDasharray={seg.strokeDasharray}
                strokeDashoffset={seg.strokeDashoffset}
                strokeLinecap="butt"
                fill="none"
                className="transition-all duration-300 cursor-pointer"
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
            ))}
          </svg>

          {/* Center text displaying hovered or total */}
          <div className="absolute text-center pointer-events-none">
            <div className="font-space text-lg font-bold text-white leading-tight">
              {hoveredIndex !== null ? `${segments[hoveredIndex].percent}%` : '100%'}
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              {hoveredIndex !== null ? segments[hoveredIndex].label.split(' ')[0] : 'Total'}
            </div>
          </div>
        </div>

        {/* Legend List on Right */}
        <div className="w-full space-y-3">
          {currentItems.map((item, idx) => (
            <div
              key={item.id}
              onMouseEnter={() => setHoveredIndex(idx)}
              onMouseLeave={() => setHoveredIndex(null)}
              className={`flex items-center justify-between p-2 rounded-md transition-colors cursor-pointer ${
                hoveredIndex === idx ? 'bg-white/[0.06]' : 'hover:bg-white/[0.03]'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={`w-3 h-3 rounded-[3px] shrink-0 ${item.color}`} />
                <span className="text-xs sm:text-sm font-medium text-slate-200">
                  {item.label}
                </span>
              </div>
              <span className="font-space font-bold text-sm sm:text-base text-white">
                {formatNumber(item.count)}
              </span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default RevenueSourcesCard;
