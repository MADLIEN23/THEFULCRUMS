import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SlidersHorizontal, ChevronDown, Check, X, RotateCcw } from 'lucide-react';

export const FilterDisclosure = ({
  items = [],
  selectedIds = [],
  onSelect,
  onConfirm,
  onReset,
  buttonLabel = 'Filter & Sort',
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [localSelected, setLocalSelected] = useState(selectedIds);

  const handleToggle = (id) => {
    const updated = localSelected.includes(id)
      ? localSelected.filter((item) => item !== id)
      : [...localSelected, id];
    setLocalSelected(updated);
    if (onSelect) onSelect(id, updated);
  };

  const handleConfirm = () => {
    if (onConfirm) onConfirm(localSelected);
    setIsOpen(false);
  };

  const handleReset = () => {
    setLocalSelected([]);
    if (onReset) onReset();
  };

  return (
    <div className={`relative inline-block ${className}`}>
      {/* Trigger Button */}
      <motion.button
        type="button"
        whileTap={{ scale: 0.97 }}
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-3.5 py-2.5 rounded-full text-xs font-semibold transition-all duration-200 border ${
          isOpen || localSelected.length > 0
            ? 'bg-blue-600 text-white border-blue-500'
            : 'bg-[#1e2226] hover:bg-[#272c30] text-slate-200 border border-[#31363a] hover:border-blue-500/50'
        }`}
      >
        <SlidersHorizontal className="w-3.5 h-3.5" />
        <span>{buttonLabel}</span>
        {localSelected.length > 0 && (
          <span className="w-5 h-5 rounded-full bg-white/20 text-white flex items-center justify-center text-[10px] font-mono">
            {localSelected.length}
          </span>
        )}
        <motion.span animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-3.5 h-3.5 opacity-70" />
        </motion.span>
      </motion.button>

      {/* Floating Animated Disclosure Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            className="absolute left-0 top-full mt-2 z-50 w-72 rounded-lg bg-[#181b1e] border border-[#31363a] p-4 shadow-2xl text-white"
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#31363a]">
              <div className="flex items-center gap-2">
                <span className="font-space font-bold text-xs text-slate-400">
                  Select Filters
                </span>
                {localSelected.length > 0 && (
                  <span className="text-[10px] font-mono text-blue-400 bg-blue-500/15 border border-blue-500/30 px-2 py-0.5 rounded-full">
                    {localSelected.length} active
                  </span>
                )}
              </div>
              {localSelected.length > 0 && (
                <button
                  type="button"
                  onClick={handleReset}
                  className="text-[11px] text-slate-400 hover:text-blue-400 transition flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              )}
            </div>

            {/* Filter Items Grid */}
            <div className="grid grid-cols-2 gap-2 mb-4 max-h-56 overflow-y-auto no-scrollbar">
              {items.map((item) => {
                const Icon = item.icon;
                const isSelected = localSelected.includes(item.id);

                return (
                  <motion.div
                    key={item.id}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => handleToggle(item.id)}
                    className={`flex items-center gap-2 p-2.5 rounded-lg cursor-pointer text-xs font-medium transition-all duration-200 border select-none ${
                      isSelected
                        ? 'bg-blue-500/15 border-blue-500 text-white font-semibold'
                        : 'bg-[#1e2226] border border-[#31363a] hover:border-blue-500/40 text-slate-300'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 transition-colors ${
                        isSelected
                          ? 'bg-blue-600 text-white'
                          : 'bg-[#181b1e] border border-[#31363a] text-slate-400'
                      }`}
                    >
                      {Icon && <Icon className="w-3.5 h-3.5" />}
                    </div>

                    <span className="truncate flex-1">{item.label}</span>

                    {isSelected && (
                      <Check className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    )}
                  </motion.div>
                );
              })}
            </div>

            {/* Confirm Button */}
            <motion.button
              type="button"
              whileTap={{ scale: 0.98 }}
              onClick={handleConfirm}
              className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Confirm Filters</span>
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FilterDisclosure;
