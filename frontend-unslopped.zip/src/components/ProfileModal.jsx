import React, { useState, useEffect } from 'react';
import { X, Clock, Pencil, Check, Camera, User } from 'lucide-react';
import { api } from '../api';

export default function ProfileModal({ user, isOpen, onClose, onSave }) {
  const [fullName, setFullName] = useState(user?.full_name || 'Alex Rivera');
  const [email, setEmail] = useState(user?.email || `${user?.username || 'admin'}@tooltrack.io`);
  const [timezone, setTimezone] = useState(user?.timezone || 'GMT-8');
  const [workingHours, setWorkingHours] = useState(user?.workingHours || '10 AM – 6 PM');
  const [title, setTitle] = useState(
    user?.title || (user?.role === 'Admin' ? 'Shop Manager' : user?.role === 'Inspector' ? 'Quality Assurance Lead' : 'Assembly Technician')
  );
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar || null);
  const [lastUpdated, setLastUpdated] = useState(user?.lastUpdated || 'Oct 17, 2026');
  const [savedFeedback, setSavedFeedback] = useState(false);
  const [saving, setSaving] = useState(false);

  // Sync state whenever modal opens or user prop changes
  useEffect(() => {
    if (isOpen && user) {
      setFullName(user.full_name || 'Alex Rivera');
      setEmail(user.email || `${user.username || 'admin'}@tooltrack.io`);
      setTimezone(user.timezone || 'GMT-8');
      setWorkingHours(user.workingHours || '10 AM – 6 PM');
      setTitle(
        user.title || (user.role === 'Admin' ? 'Shop Manager' : user.role === 'Inspector' ? 'Quality Assurance Lead' : 'Assembly Technician')
      );
      setAvatarUrl(user.avatar || null);
      setLastUpdated(user.lastUpdated || 'Oct 17, 2026');
      setSavedFeedback(false);
    }
  }, [isOpen, user]);

  // Compute initials dynamically from Full Name (e.g., "Alex Rivera" -> "AR")
  const getInitials = (name) => {
    if (!name || !name.trim()) return 'AR';
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  // Handle avatar photo selection via the pencil icon
  const handleAvatarChange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setAvatarUrl(uploadEvent.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);

    const nowFormatted = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });

    const updatedProfile = {
      ...user,
      full_name: fullName.trim(),
      email: email.trim(),
      title: title.trim(),
      timezone,
      workingHours,
      avatar: avatarUrl,
      lastUpdated: nowFormatted
    };

    setLastUpdated(nowFormatted);

    try {
      if (api && api.updateProfile) {
        await api.updateProfile(updatedProfile);
      }
    } catch (err) {
      console.warn('Profile save warning:', err);
    }

    if (onSave) {
      onSave(updatedProfile);
    }

    setSavedFeedback(true);
    setSaving(false);

    setTimeout(() => {
      setSavedFeedback(false);
      onClose();
    }, 700);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-lg bg-[#181b1e] border border-[#31363a] p-6 sm:p-8 text-white shadow-2xl">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#31363a] mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-md bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <User className="w-4 h-4" />
            </div>
            <h3 className="font-space font-bold text-lg text-white">Edit Personnel Profile</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave}>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Form Fields */}
            <div className="md:col-span-7 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Full name
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Alex Rivera"
                  className="w-full px-3.5 py-2.5 rounded-md bg-[#1e2226] border border-[#31363a] text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@tooltrack.io"
                  className="w-full px-3.5 py-2.5 rounded-md bg-[#1e2226] border border-[#31363a] text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Timezone
                  </label>
                  <select
                    value={timezone}
                    onChange={(e) => setTimezone(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-md bg-[#1e2226] border border-[#31363a] text-sm text-white focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
                  >
                    <option value="GMT-8">GMT-8 (Pacific)</option>
                    <option value="GMT-5">GMT-5 (Eastern)</option>
                    <option value="GMT+0">GMT+0 (UTC)</option>
                    <option value="GMT+5:30">GMT+5:30 (IST)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Working hours
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={workingHours}
                      onChange={(e) => setWorkingHours(e.target.value)}
                      placeholder="10 AM – 6 PM"
                      className="w-full px-3 py-2.5 pr-8 rounded-md bg-[#1e2226] border border-[#31363a] text-xs text-white focus:outline-none focus:border-blue-500 font-mono transition-colors"
                    />
                    <Clock className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Shop Manager"
                  className="w-full px-3.5 py-2.5 rounded-md bg-[#1e2226] border border-[#31363a] text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                  required
                />
              </div>
            </div>

            {/* Right Column: Live Dynamic Avatar Preview */}
            <div className="md:col-span-5 flex flex-col items-center justify-center p-6 border-l md:border-[#31363a] text-center">
              <span className="text-xs text-blue-400 font-semibold mb-4 font-mono">
                PREVIEW
              </span>

              {/* Avatar circle with sleek gradient ring */}
              <div className="relative w-28 h-28 rounded-full bg-blue-600 p-1 mb-4 group">
                <div className="w-full h-full rounded-full bg-[#181b1e] flex items-center justify-center text-3xl font-bold font-space text-white overflow-hidden">
                  {avatarUrl ? (
                    <img src={avatarUrl} alt={fullName} className="w-full h-full object-cover" />
                  ) : (
                    <span>{getInitials(fullName)}</span>
                  )}
                </div>

                {/* Interactive Pencil Icon: click to upload photo */}
                <label
                  htmlFor="profile-avatar-upload"
                  className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-[#1e2226] hover:bg-blue-600 border-2 border-[#181b1e] flex items-center justify-center text-slate-300 hover:text-white cursor-pointer transition-all hover:scale-110"
                  title="Upload avatar photo"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  <input
                    id="profile-avatar-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Dynamic live preview of Name & Title */}
              <div className="font-bold text-base text-white tracking-tight">
                {fullName || 'Alex Rivera'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {title || 'Shop Manager'}
              </div>

              {/* Working hours pill */}
              <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1e2226] border border-[#31363a] text-[11px] text-slate-300 font-mono">
                <Clock className="w-3 h-3 text-blue-400" />
                <span>{workingHours || '10 AM – 6 PM'}</span>
              </div>
            </div>
          </div>

          {/* Footer with date and actions */}
          <div className="mt-8 pt-5 border-t border-[#31363a] flex items-center justify-between text-xs text-slate-400">
            <span>Last updated: {lastUpdated}</span>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2 rounded-full bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-white font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2 rounded-full bg-blue-600 text-white font-semibold hover:bg-blue-500 transition flex items-center gap-1.5 disabled:opacity-50"
              >
                {savedFeedback ? (
                  <>
                    <Check className="w-4 h-4 text-white" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <span>{saving ? 'Saving...' : 'Save changes'}</span>
                )}
              </button>
            </div>
          </div>
        </form>

      </div>
    </div>
  );
}
