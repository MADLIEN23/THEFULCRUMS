import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, CornerDownLeft, X } from 'lucide-react';

export const CommandSearch = ({
  items = [],
  placeholder = 'Type a command or search...',
  onQueryChange,
  className = ''
}) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  // Filter items by query
  const filteredItems = items.filter((item) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      (item.section && item.section.toLowerCase().includes(q))
    );
  });

  // Group by section
  const sections = Array.from(new Set(filteredItems.map((item) => item.section || 'General')));

  // Keyboard shortcut (Cmd+K or Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsOpen((prev) => !prev);
        if (!isOpen) {
          setTimeout(() => inputRef.current?.focus(), 50);
        }
      } else if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  // Handle outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Arrow key navigation inside dropdown
  const handleKeyDown = (e) => {
    if (!isOpen || filteredItems.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % filteredItems.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filteredItems.length) % filteredItems.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const current = filteredItems[selectedIndex];
      if (current && current.action) {
        current.action();
        setIsOpen(false);
      }
    }
  };

  const handleSelect = (item) => {
    if (item.action) item.action();
    setIsOpen(false);
  };

  return (
    <div ref={containerRef} className={`relative w-full max-w-md ${className}`}>
      {/* Search Input Bar */}
      <div className="relative flex items-center">
        <Search className="absolute left-3.5 w-4 h-4 text-blue-400 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setSelectedIndex(0);
            if (onQueryChange) onQueryChange(e.target.value);
            if (!isOpen) setIsOpen(true);
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full pl-10 pr-16 py-2.5 rounded-full bg-[#1e2226] border border-[#31363a] text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-blue-500 transition-all"
        />
        <div className="absolute right-3 flex items-center gap-1.5">
          {query ? (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                if (onQueryChange) onQueryChange('');
              }}
              className="text-slate-400 hover:text-white text-xs"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="hidden sm:inline-flex items-center gap-0.5 px-2 py-0.5 text-[10px] font-mono text-slate-400 bg-[#181b1e] border border-[#31363a] rounded-md">
              <span>⌘</span>K
            </kbd>
          )}
        </div>
      </div>

      {/* Floating Animated Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            className="absolute left-0 right-0 top-full mt-2 z-50 rounded-lg bg-[#181b1e] border border-[#31363a] shadow-2xl overflow-hidden max-h-80 overflow-y-auto"
          >
            {filteredItems.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No matching results found for <span className="text-white">"{query}"</span>
              </div>
            ) : (
              <div className="p-2 space-y-2">
                {sections.map((sectionName) => {
                  const sectionItems = filteredItems.filter(
                    (item) => (item.section || 'General') === sectionName
                  );
                  if (sectionItems.length === 0) return null;

                  return (
                    <div key={sectionName} className="space-y-1">
                      <div className="px-3 py-1 text-[10px] font-mono text-blue-400 font-bold">
                        {sectionName}
                      </div>

                      {sectionItems.map((item) => {
                        const globalIndex = filteredItems.indexOf(item);
                        const isSelected = globalIndex === selectedIndex;

                        return (
                          <div
                            key={item.id}
                            onMouseEnter={() => setSelectedIndex(globalIndex)}
                            onClick={() => handleSelect(item)}
                            className={`flex items-center justify-between px-3 py-2 rounded-md text-xs cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-blue-600 text-white font-semibold'
                                : 'text-slate-300 hover:bg-[#1e2226]'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 truncate">
                              <span
                                className={`shrink-0 ${
                                  isSelected
                                    ? 'text-white'
                                    : 'text-slate-400'
                                }`}
                              >
                                {item.icon}
                              </span>
                              <span className="truncate">{item.title}</span>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              {item.shortcut && (
                                <kbd className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                                  isSelected ? 'bg-red-700/50 text-white border-red-400/30' : 'bg-[#121416] text-zinc-400 border-[#31363a]'
                                }`}>
                                  {item.shortcut}
                                </kbd>
                              )}
                              {isSelected && (
                                <CornerDownLeft className="w-3.5 h-3.5 text-white" />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CommandSearch;
