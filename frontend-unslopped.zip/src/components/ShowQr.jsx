import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import QRCode from 'qrcode';
import { QrCode, Copy, Check, Download, X, ExternalLink } from 'lucide-react';

export const ShowQr = ({
  value = 'https://tooltrack.internal/equipment',
  buttonLabel = 'Show QR Code',
  onCopy,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (value) {
      QRCode.toDataURL(value, {
        width: 320,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff'
        }
      })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('Error generating QR:', err));
    }
  }, [value]);

  const handleCopy = (e) => {
    e?.stopPropagation();
    navigator.clipboard.writeText(value);
    setCopied(true);
    if (onCopy) onCopy(value);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (e) => {
    e?.stopPropagation();
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `qrcode_${value.replace(/[^a-zA-Z0-9]/g, '_')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold
                   bg-[#1e2226] hover:bg-[#272c30] text-slate-200 border border-[#31363a] hover:border-blue-500
                   transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] ${className}`}
      >
        <QrCode className="w-3.5 h-3.5 text-blue-400" />
        <span>{buttonLabel}</span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80"
            onClick={() => setIsOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 15 }}
              transition={{ type: 'spring', stiffness: 350, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-sm rounded-lg bg-[#181b1e] border border-[#31363a] p-6 shadow-2xl text-white"
            >
              {/* Close Button */}
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 w-7 h-7 rounded-full bg-[#1e2226] hover:bg-blue-600 flex items-center justify-center text-slate-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-9 h-9 rounded-md bg-blue-600/20 border border-blue-500/30 flex items-center justify-center">
                  <QrCode className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-space font-bold text-base text-white">Equipment QR Code</h3>
                  <p className="text-[11px] text-slate-400 font-mono">Scan via handheld terminal or mobile</p>
                </div>
              </div>

              {/* QR Code Container */}
              <div className="p-4 rounded-lg bg-white flex items-center justify-center my-4">
                {qrDataUrl ? (
                  <img src={qrDataUrl} alt="QR Code" className="w-56 h-56 rounded-lg object-contain" />
                ) : (
                  <div className="w-56 h-56 flex items-center justify-center text-slate-400 text-xs">
                    Generating QR...
                  </div>
                )}
              </div>

              {/* Value String Preview */}
              <div className="p-2.5 rounded-md bg-[#1e2226] border border-[#31363a] font-mono text-[11px] text-slate-300 break-all mb-4 text-center">
                {value}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-[#31363a]">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="flex-1 py-2 px-3 rounded-md bg-[#1e2226] hover:bg-[#272c30] border border-[#31363a] text-xs font-semibold text-white transition flex items-center justify-center gap-1.5"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-blue-400" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex-1 py-2 px-3 rounded-md bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white transition flex items-center justify-center gap-1.5 font-space"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ShowQr;
