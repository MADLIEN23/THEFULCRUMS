// Central API Client for ToolTrack
// Handles JWT storage, authorization headers, and unified HTTP requests

const API_BASE = '/api';

export const api = {
  getToken() {
    return localStorage.getItem('tooltrack_token');
  },

  setAuth(token, user) {
    localStorage.setItem('tooltrack_token', token);
    localStorage.setItem('tooltrack_user', JSON.stringify(user));
  },

  clearAuth() {
    localStorage.removeItem('tooltrack_token');
    localStorage.removeItem('tooltrack_user');
  },

  getUser() {
    const raw = localStorage.getItem('tooltrack_user');
    try {
      return raw ? JSON.parse(raw) : {
        id: 1,
        username: 'admin',
        full_name: 'Alex Rivera',
        role: 'Admin',
        department: 'Shop Management'
      };
    } catch {
      return {
        id: 1,
        username: 'admin',
        full_name: 'Alex Rivera',
        role: 'Admin',
        department: 'Shop Management'
      };
    }
  },

  async request(endpoint, options = {}, isRetry = false) {
    let token = this.getToken();

    // Auto-authenticate default demo user if token is missing entirely
    if (!token && endpoint !== '/auth/login' && !isRetry) {
      try {
        const loginRes = await fetch(`${API_BASE}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: 'admin', password: 'password123' })
        });
        const loginData = await loginRes.json();
        if (loginRes.ok && loginData.token) {
          this.setAuth(loginData.token, loginData.user);
          token = loginData.token;
        }
      } catch (e) {
        console.warn('Initial session boot note:', e.message);
      }
    }

    const headers = { ...options.headers };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    // Do not set Content-Type if sending FormData (browser sets boundary automatically)
    if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    const data = await res.json().catch(() => ({}));

    // Auto-recover if token is expired, invalid, or unauthorized
    if (res.status === 401 || (res.status === 403 && data.error && data.error.toLowerCase().includes('token'))) {
      if (endpoint !== '/auth/login' && !isRetry) {
        try {
          const storedUser = this.getUser();
          const username = (storedUser && storedUser.username) ? storedUser.username : 'admin';
          const refreshRes = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password: 'password123' })
          });
          const refreshData = await refreshRes.json();
          if (refreshRes.ok && refreshData.token) {
            this.setAuth(refreshData.token, refreshData.user);
            // Re-execute with new token
            return this.request(endpoint, options, true);
          }
        } catch (refreshErr) {
          console.warn('Transparent token recovery failed:', refreshErr.message);
        }

        this.clearAuth();
        window.dispatchEvent(new Event('auth-expired'));
        throw new Error(data.error || 'Your session has expired. Please sign in again.');
      }
      throw new Error(data.error || 'Invalid username or password.');
    }

    if (!res.ok) {
      throw new Error(data.error || `Request failed with status ${res.status}`);
    }

    return data;
  },

  async login(username, password) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
    this.setAuth(data.token, data.user);
    return data;
  },

  async getMe() {
    return this.request('/auth/me');
  },

  async updateProfile(profileData) {
    const currentUser = this.getUser() || {};
    const updatedUser = { ...currentUser, ...profileData };
    this.setAuth(this.getToken(), updatedUser);

    try {
      const res = await this.request('/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(profileData)
      });
      if (res && res.user) {
        this.setAuth(this.getToken(), { ...updatedUser, ...res.user });
        return res.user;
      }
    } catch (err) {
      console.warn('Backend profile update note:', err.message);
    }
    return updatedUser;
  },

  async getTools(params = {}) {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '' && v !== 'All') {
        query.set(k, v);
      }
    });
    const qs = query.toString() ? `?${query.toString()}` : '';
    return this.request(`/tools${qs}`);
  },

  async getTool(id) {
    return this.request(`/tools/${id}`);
  },

  async registerTool(toolData) {
    return this.request('/tools', {
      method: 'POST',
      body: JSON.stringify(toolData)
    });
  },

  async addEvent(toolId, eventData) {
    let body;
    let headers = {};

    if (eventData instanceof FormData) {
      body = eventData;
    } else {
      body = JSON.stringify(eventData);
      headers['Content-Type'] = 'application/json';
    }

    return this.request(`/tools/${toolId}/events`, {
      method: 'POST',
      headers,
      body
    });
  },

  async getAlerts() {
    return this.request('/alerts');
  },

  async getReportsSummary() {
    return this.request('/reports/summary');
  }
};
